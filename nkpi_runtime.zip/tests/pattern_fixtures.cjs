/* Artificial engineering cases. NEVER loaded by the application. */
const z=7.8;
function surface(eye='OD',visit='first',shift=0){
 const x=Array.from({length:61},(_,i)=>+(i*.15-4.5).toFixed(2)),g=fn=>x.map(y=>x.map(x=>Math.hypot(x,y)>4.5?null:fn(x,y))),b=(x,y)=>Math.exp(-((x-.45)**2+(y+.75)**2)/1.35);
 return {schema:'nkpi-corneal-surface-1',kind:'measured',source:'device_numeric_export',eye,visit,units:{xy:'mm',z:'mm',elevation:'um',thickness:'um',curvature:'D'},coordinate_system:{origin:'corneal_vertex',x_positive:eye==='OD'?'nasal':'temporal',y_positive:'superior',z_positive:'anterior'},comparison:{alignment:'verified_common_grid',registration_id:'engineering-fixture',map_definition_id:'axial-engineering'},x_mm:x,y_mm:x,
 anterior:{z_mm:g((x,y)=>Math.sqrt(z*z-x*x-y*y)-z+.07*b(x,y)),curvature_type:'axial',curvature_D:g((x,y)=>44+9*b(x,y)+shift*b(x,y)),elevation_um:g((x,y)=>10+65*b(x,y)),elevation_reference:{type:'best_fit_sphere',fit_diameter_mm:8,reference_id:'engineering-fixed-front'}},
 posterior:{z_mm:g((x,y)=>Math.sqrt(z*z-x*x-y*y)-z+.07*b(x,y)-(510-65*b(x,y))/1000),curvature_type:'axial',curvature_D:g((x,y)=>-6.5-1.1*b(x,y)-.15*shift*b(x,y)),elevation_um:g((x,y)=>20+80*b(x,y)),elevation_reference:{type:'best_fit_sphere',fit_diameter_mm:8,reference_id:'engineering-fixed-back'}},
 thickness_um:g((x,y)=>510-65*b(x,y)-8*shift*b(x,y)),thickness_definition:'device_pachymetry'};
}
function report(eye='OD',visit='first',shift=0){return {eye,visit,source_id:'engineering-'+eye+'-'+visit,scan_quality:'ok',pages:[],surface:surface(eye,visit,shift)};}
function input(eye='OD',paired=false){return {eye,enabled:true,mode:paired?'longitudinal':'baseline',age:23,verified:true,treatment:'untreated',scan_quality:paired?{first:'ok',latest:'ok'}:{first:'ok'},first:{A:7.3,B:6.1,C:445,Kmax:54,BAD_D:4.2,ARTmax:220},latest:paired?{A:7.2,B:6,C:435,Kmax:55,BAD_D:4.5,ARTmax:205}:null,interval_days:paired?180:null,landmarks:null,history:[],context:{}};}
function imageReport(eye='OD',visit='first'){
 const grid=(n,extent,fn)=>Array.from({length:n},(_,j)=>Array.from({length:n},(_,i)=>{const r=(n-1)/2,x=(i-r)*9*extent/(n-1),y=(r-j)*9*extent/(n-1);if(Math.hypot(i-r,j-r)>r+1e-8)return null;const v=fn(x,y);return {value:v,lo:v-.5,hi:v+.5,sampling:'direct'};}));
 const f={anterior:(x,y)=>44+6*Math.exp(-(x*x+(y+.6)**2)),posterior:(x,y)=>7+.8*Math.exp(-(x*x+(y+.6)**2)),thickness:(x,y)=>510-65*Math.exp(-(x*x+(y+.6)**2))};
 const maps=Object.entries(f).map(([id,fn])=>({schema:'nkpi-report-image-map-1',id,source:'report_color_estimate',unit:id==='thickness'?'µm':'D',map_type:id==='thickness'?'pachymetry':'axial',extent:2/3,diameter_mm:9,registration:'printed_plot_circle',grid:grid(41,2/3,fn),legend:{anchors:[{value: id==='thickness'?300:0},{value:id==='thickness'?900:100}]}}));
 return {eye,visit,source_id:'engineering-image-'+eye+'-'+visit,image_maps:maps,scan_quality:'ok',pages:[]};
}
module.exports={surface,report,input,imageReport};
