'use strict';
const assert=require('node:assert/strict');
const {test}=require('node:test');
const I=require('../components/image_regions.js');

function fixture(){
 const width=300,height=280,c={cx:150,cy:140,r:110},im={width,height,data:new Uint8ClampedArray(width*height*4).fill(255)};
 const palette=[{rgb:[55,150,220],value:-20,lo:-22,hi:-18,step:4},{rgb:[235,155,55],value:25,lo:23,hi:27,step:4}];
 for(let y=28;y<252;y++)for(let x=38;x<262;x++)if(Math.hypot(x-c.cx,y-c.cy)<106){
  const color=x<c.cx+25?palette[0].rgb:palette[1].rgb;
  im.data.set([...color,255],(y*width+x)*4);
 }
 // A genuine white area is too broad for the narrow-label recovery rule.
 for(let y=125;y<155;y++)for(let x=175;x<205;x++)im.data.set([255,255,255,255],(y*width+x)*4);
 return {im,c,palette};
}

test('Detailed colors sample original image locations while legacy grids stay unchanged',()=>{
 const {im,c,palette}=fixture(),before=JSON.stringify({central:I.grid(im,c,palette),full:I.displayGrid(im,c,palette,9)});
 const detail=I.detailGrid(im,c,palette,9,'elevation_um');
 assert.equal(detail.elevation_um.length,121);
 assert.equal(detail.elevation_um[60][60].value,-20);
 assert.equal(detail.elevation_um[60][108].value,25);
 assert.equal(detail.elevation_um[60][82],null,'White report region remains unavailable');
 assert.equal(detail.elevation_um[0][0],null,'Outside map circle is never filled');
 assert.equal(JSON.stringify({central:I.grid(im,c,palette),full:I.displayGrid(im,c,palette,9)}),before);
 I.validateDetailGrid(detail,{diameter_mm:9},'elevation_um');
});

test('Memoized detailed reads equal the original calibrated color sampler',()=>{
 const {im,c,palette}=fixture(),detail=I.detailGrid(im,c,palette,9);
 for(const [i,j]of [[60,60],[81,60],[108,60],[47,23],[40,80],[60,12],[12,60]]){
  const x=(i-60)/60,y=(j-60)/60;
  assert.deepEqual(detail.grid[j][i],I.sampleColor(im,c,palette,c.cx+x*c.r,c.cy+y*c.r));
 }
});

test('Detailed grid validation rejects wrong geometry, coverage and unbounded samples',()=>{
 const {im,c,palette}=fixture(),detail=I.detailGrid(im,c,palette,9);
 for(const edit of [d=>d.diameter_mm=8,d=>d.extent=2/3,d=>d.grid.pop(),d=>d.grid[10].pop(),d=>d.coverage=.01,d=>d.grid[0][0]={value:25,lo:23,hi:27,sampling:'direct'},d=>d.grid[60][60].value=Infinity,d=>d.grid[60][60].lo=999,d=>d.grid[60][60].sampling='invented']){
  const bad=structuredClone(detail);edit(bad);assert.throws(()=>I.validateDetailGrid(bad,{diameter_mm:9}));
 }
});
