'use strict';
// Display-domain and bounded gap-repair checks. Analytic/report-color holdouts
// assess implementation behavior, not agreement with native clinical data.
const assert=require('node:assert/strict');
const C=require('../components/cornea/integrated_coverage.js');
let count=0;
const test=(name,fn)=>{fn();count++;console.log('PASS '+name);};
const close=(a,b,t=1e-8)=>assert(Math.abs(a-b)<t,`${a} != ${b}`);
const freeze=o=>{if(o&&typeof o==='object'){Object.freeze(o);Object.values(o).forEach(freeze);}return o;};
function fixture({n=81,r=3,field='anterior',fn=(x,y)=>46+2*x-y,sourceKind='report-image',bin=2}={}){
 const axis=Array.from({length:n},(_,i)=>-r+2*r*i/(n-1)),values=[],status=[],sampling=[],intervalWidths=[],vertices=[],triangles=[];
 for(let j=0;j<n;j++)for(let i=0;i<n;i++){
  const x=axis[i],y=axis[j],inside=Math.hypot(x,y)<=r+1e-8,value=inside?fn(x,y):null;
  values.push(value);status.push(inside?1:0);sampling.push(inside?'direct':null);intervalWidths.push(inside?bin:null);
  vertices.push(inside?{front:[x,y,-.04*(x*x+y*y)],back:null,thickness:490+2*x,[field]:value}:null);
 }
 for(let j=0;j<n-1;j++)for(let i=0;i<n-1;i++){const a=j*n+i,b=a+1,c=a+n,d=c+1;for(const ids of [[a,b,c],[b,d,c]])if(ids.every(k=>vertices[k]))triangles.push(ids);}
 const descriptor={schema:'nkpi-integrated-display-map-1',field,width:n,height:n,xMin:-r,xMax:r,yMin:-r,yMax:r,radius_mm:r,values,status,sampling,intervalWidths,sourceKind,detail:'original-map-detail'};
 const model={kind:sourceKind==='native'?'native':'estimated',mapSource:sourceKind==='native'?'native':'image',sourceKind,hasPatientGeometry:true,eye:'OD',visit:'latest',nx:n,ny:n,axisX:axis,axisY:[...axis],radius:r,vertices,triangles,displayMaps:{[field]:descriptor}};
 return {model,descriptor,axis,n,center:(n*n-1)/2};
}
function remove(f,indices,status=0){for(const k of indices){f.descriptor.values[k]=null;f.descriptor.status[k]=status;f.descriptor.sampling[k]=null;f.descriptor.intervalWidths[k]=null;}}
function strip(f,width=1,diagonal=false){const center=(f.n-1)/2,indices=[];for(let j=0;j<f.n;j++)for(let k=0;k<width;k++){const i=(diagonal?j:center)+k-Math.floor(width/2);if(i>=0&&i<f.n&&f.descriptor.status[j*f.n+i]===1)indices.push(j*f.n+i);}remove(f,indices);return indices;}

test('Full map support is independent of missing anterior triangles',()=>{
 const f=fixture(),k=f.center;
 f.model.vertices[k]=null;f.model.triangles=f.model.triangles.filter(ids=>!ids.includes(k));
 const before=JSON.stringify(f.model),p=C.prepare(f.model),surface=C.getField(p,'anterior',false),map=C.getMapField(p,'anterior',false);
 assert.equal(C.sample(surface,0,0),null);close(C.sample(map,0,0).value,46);
 assert.equal(surface.eligible[k],0);assert.equal(map.eligible[k],1);assert.equal(C.hasSurface(p,0,0),false);assert(C.hasSurface(p,1,1));assert.equal(JSON.stringify(f.model),before);
});
test('The map retains its own physical circle beyond a smaller reconstructed aperture',()=>{
 const f=fixture();f.model.radius=1.5;const p=C.prepare(f.model),map=C.getMapField(p,'anterior',false),surface=C.getField(p,'anterior',false);
 assert.equal(map.radius_mm,3);assert.equal(surface.radius_mm,1.5);close(C.sample(map,2.1,0).value,50.2);
 assert.equal(C.sample(surface,2.1,0),null);assert.equal(C.hasSurface(p,2.1,0),false);
 assert.equal(C.sample(map,2.13,2.13),null);assert.equal(C.sampleStatus(map,2.13,2.13),null);
});
test('A report map remains usable without any supported patient geometry',()=>{
 const f=fixture();f.model.hasPatientGeometry=false;f.model.kind='reference';f.model.triangles=[];
 const p=C.prepare(f.model);assert.equal(C.getField(p,'anterior'),null);close(C.sample(C.getMapField(p,'anterior'),0,0).value,46);assert.equal(C.hasSurface(p,0,0),false);
});
test('Uncertain report colors retain a preview and never become exact samples or donors',()=>{
 const f=fixture();remove(f,[f.center],3);f.descriptor.previewValues=Array(f.n*f.n).fill(null);f.descriptor.previewValues[f.center]=80;
 f.descriptor.uncertaintyKind=Array(f.n*f.n).fill(null);f.descriptor.uncertaintyKind[f.center]='endpoint';
 remove(f,[f.center+1]);const p=C.prepare(f.model);
 for(const get of [C.getField,C.getMapField]){const g=get(p,'anterior');assert.equal(C.sample(g,0,0),null);assert.equal(g.status[f.center+1],0);
  assert.deepEqual(C.sampleStatus(g,0,0),{index:f.center,status:3,category:'uncertain',eligible:true,previewValue:80,uncertaintyKind:'endpoint'});
  assert.equal(g.coverage.uncertain,1);assert.equal(g.coverage.clipped,1);assert.equal(g.coverage.total,g.coverage.source+g.coverage.estimated+g.coverage.unavailable);assert(g.coverage.uncertain<=g.coverage.unavailable);
 }
});
test('An entirely uncertain map is available for patterned preview with no accepted value range',()=>{
 const f=fixture();f.descriptor.previewValues=f.descriptor.values.slice();f.descriptor.uncertaintyKind=f.descriptor.status.map(s=>s?'ambiguous':null);f.descriptor.status=f.descriptor.status.map(s=>s?3:0);f.descriptor.values.fill(null);
 const p=C.prepare(f.model);for(const get of [C.getField,C.getMapField]){const g=get(p,'anterior');assert(g);assert.equal(g.range,null);assert.equal(g.coverage.source,0);assert(g.coverage.uncertain>0);assert.equal(C.sample(g,0,0),null);assert.equal(C.sampleStatus(g,0,0).uncertaintyKind,'ambiguous');}
});
test('Interior portions of a narrow rim-connected stripe are estimated without filling the rim',()=>{
 const f=fixture();strip(f,3);const p=C.prepare(f.model);
 for(const get of [C.getField,C.getMapField]){const raw=get(p,'anterior',false),g=get(p,'anterior');assert.equal(raw.status[f.center],0);assert.equal(g.status[f.center],2);close(g.values[f.center],46);
  assert.equal(g.status[(f.n-1)/2],0);assert.equal(g.status[(f.n-1)*f.n+(f.n-1)/2],0);
  assert(g.diagnostics.some(d=>d.narrowFilled>0&&d.remaining>0));assert(g.diagnostics.filter(d=>d.narrowFilled).every(d=>d.maxCrossWidthMM<=.30+1e-8));
 }
});
test('A physically narrow diagonal stripe can be repaired with original opposed support',()=>{
 const f=fixture();strip(f,1,true);const g=C.getMapField(C.prepare(f.model),'anterior');assert.equal(g.status[f.center],2);close(g.values[f.center],46);assert(g.diagnostics.some(d=>d.narrowFilled>0));
});
test('Broad disk and wide stripe voids remain missing even in an otherwise smooth field',()=>{
 for(const shape of ['disk','wide-stripe']){const f=fixture(),missing=[];for(let j=0;j<f.n;j++)for(let i=0;i<f.n;i++){
   if(f.descriptor.status[j*f.n+i]===1&&(shape==='disk'?Math.hypot(f.axis[i],f.axis[j])<=.48:Math.abs(f.axis[i])<=.23))missing.push(j*f.n+i);
  }remove(f,missing);const g=C.getMapField(C.prepare(f.model),'anterior');assert.equal(g.coverage.estimated,0,shape);assert(missing.every(k=>g.status[k]===0));}
});
test('The true geometry boundary remains excluded while an independent map may use its own support',()=>{
 const f=fixture();strip(f);const cut=f.center+f.n;f.model.vertices[cut]=null;f.model.triangles=f.model.triangles.filter(ids=>!ids.includes(cut));
 const p=C.prepare(f.model),surface=C.getField(p,'anterior'),map=C.getMapField(p,'anterior');assert.equal(surface.status[cut],0);assert.equal(surface.eligible[cut],0);assert.equal(surface.status[f.center],0);assert.equal(map.status[cut],2);assert.equal(C.hasSurface(p,0,.075),false);
});
test('A nearby uncertain interval blocks local stripe repair without disabling distant supported portions',()=>{
 const f=fixture();strip(f);remove(f,[f.center+2],3);const g=C.getMapField(C.prepare(f.model),'anterior');assert.equal(g.status[f.center],0);assert.equal(g.status[f.center+2],3);assert.equal(g.status[f.center+12*f.n],2);
});
test('Native missing values and recovered-only color support are never repaired',()=>{
 for(const sourceKind of ['native','report-image']){const f=fixture({sourceKind});strip(f);if(sourceKind==='report-image')f.descriptor.sampling=f.descriptor.sampling.map(v=>v?'local_color':null);
  const p=C.prepare(f.model);for(const get of [C.getField,C.getMapField]){const g=get(p,'anterior');assert.equal(g.coverage.estimated,0);assert.equal(g.status[f.center],0);}
 }
});
test('Local residual checks reject a stripe across a steep inconsistent field',()=>{
 const f=fixture({fn:(x,y)=>45+18*Math.sin(x*35)*Math.cos(y*29),bin:.1});strip(f,3);const g=C.getMapField(C.prepare(f.model),'anterior');assert.equal(g.status[f.center],0);assert.equal(C.sample(g,0,0),null);
});
test('Estimates preserve all source arrays, original point readings, geometry and source ranges',()=>{
 const f=fixture({field:'thickness',fn:(x,y)=>480+3*x-2*y,bin:8});strip(f,3);const before=JSON.stringify(f.model);freeze(f.model);const p=C.prepare(f.model);
 for(const get of [C.getField,C.getMapField]){const raw=get(p,'thickness',false),g=get(p,'thickness');assert.equal(g.status[f.center],2);assert.deepEqual(g.sourceValues,raw.sourceValues);assert.deepEqual(g.sourceStatus,raw.sourceStatus);assert.deepEqual(g.range,raw.range);
  for(let k=0;k<g.status.length;k++)if(g.sourceStatus[k]===1){assert.equal(g.status[k],1);assert.equal(g.values[k],g.sourceValues[k]);}
  assert.equal(g.sampling[f.center],null);assert.equal(g.sourceValues[f.center],null);assert.equal(g.sourceStatus[f.center],0);
 }
 assert.equal(JSON.stringify(f.model),before);assert.equal(f.model.vertices[f.center].thickness,480);
});
test('Multiple connected affine holdout strips reproduce source values without recursive donors',()=>{
 let checked=0;for(const width of [1,2,3])for(const diagonal of [false,true]){const f=fixture(),original=f.descriptor.values.slice(),hidden=strip(f,width,diagonal),g=C.getMapField(C.prepare(f.model),'anterior');let filled=0;
  for(const k of hidden)if(g.status[k]===2){close(g.values[k],original[k]);assert.equal(g.sourceStatus[k],0);assert.equal(g.sampling[k],null);filled++;}
  // Three diagonal grid columns have a larger physical width and may abstain.
  if(width<3||!diagonal)assert(filled>0);checked+=filled;
 }assert(checked>100);
});
console.log(`${count} independent map-support checks passed.`);
