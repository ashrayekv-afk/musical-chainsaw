/* Independent quantitative display support.
 * No value from this module is written into the source model or calculator.
 * Source means an imported sample, including approximate report-color samples;
 * it does not turn a report image into an independently measured device grid.
 */
(function(root){'use strict';
const FIELDS=Object.freeze(['thickness','anterior','posterior','elevation','posterior_elevation']);
const STATUS=Object.freeze({unavailable:0,source:1,estimated:2,uncertain:3,clipped:3});
// Engineering display limits, assessed with spatial holdouts. These are not
// clinical thresholds or guarantees about an unseen pathological extremum.
const POLICY=Object.freeze({maxSpanMM:.30,maxAreaMM2:.075,neighborRadiusMM:.45,minNeighbors:8,maxResidualBinFraction:.6,minNarrowAspect:4});
const finite=Number.isFinite,EPS=1e-8,cache=new WeakMap();
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const median=a=>{if(!a.length)return null;const b=[...a].sort((x,y)=>x-y);return b[Math.floor(b.length/2)];};
function solve(a,b){
 a=a.map((row,i)=>[...row,b[i]]);
 for(let i=0;i<b.length;i++){
  let pivot=i;for(let j=i+1;j<b.length;j++)if(Math.abs(a[j][i])>Math.abs(a[pivot][i]))pivot=j;
  [a[i],a[pivot]]=[a[pivot],a[i]];if(Math.abs(a[i][i])<1e-11)return null;
  const d=a[i][i];a[i]=a[i].map(v=>v/d);
  for(let j=0;j<b.length;j++)if(j!==i){const f=a[j][i];a[j]=a[j].map((v,k)=>v-f*a[i][k]);}
 }
 return a.map(row=>row[b.length]);
}
function bracket(axis,value){
 if(!axis||axis.length<2)return null;
 const ascending=axis[axis.length-1]>axis[0],v=ascending?value:-value;
 const first=ascending?axis[0]:-axis[0],last=ascending?axis[axis.length-1]:-axis[axis.length-1];
 if(v<first-EPS||v>last+EPS)return null;
 let lo=0,hi=axis.length-1;
 while(hi-lo>1){const mid=(lo+hi)>>1;if((ascending?axis[mid]:-axis[mid])<=v)lo=mid;else hi=mid;}
 const index=Math.min(axis.length-2,lo),t=(value-axis[index])/(axis[index+1]-axis[index]);
 return {index,t:clamp(t,0,1)};
}
function geometryTest(model){
 if(!model||model.hasPatientGeometry===false||model.kind==='reference'||!model.triangles?.length)return ()=>false;
 const x=model.axisX,y=model.axisY,nx=model.nx;
 if(!x||!y||x.length!==nx||y.length!==model.ny)return ()=>false;
 const triangles=new Set(model.triangles.map(ids=>[...ids].sort((a,b)=>a-b).join(',')));
 const has=ids=>triangles.has(ids.sort((a,b)=>a-b).join(','));
 return (px,py)=>{
  if(Math.hypot(px,py)>model.radius+EPS)return false;
  const bx=bracket(x,px),by=bracket(y,py);if(!bx||!by)return false;
  const ii=[bx.index],jj=[by.index];
  if(bx.t<EPS&&bx.index>0)ii.push(bx.index-1);if(bx.t>1-EPS&&bx.index<x.length-2)ii.push(bx.index+1);
  if(by.t<EPS&&by.index>0)jj.push(by.index-1);if(by.t>1-EPS&&by.index<y.length-2)jj.push(by.index+1);
  for(const i of ii)for(const j of jj){
   const fx=(px-x[i])/(x[i+1]-x[i]),fy=(py-y[j])/(y[j+1]-y[j]);
   if(fx<-EPS||fx>1+EPS||fy<-EPS||fy>1+EPS)continue;
   const a=j*nx+i,b=a+1,c=a+nx,d=c+1;
   if(fx+fy<=1+EPS&&has([a,b,c]))return true;
   if(fx+fy>=1-EPS&&has([b,d,c]))return true;
   if(fy<=fx+EPS&&has([a,b,d]))return true;
   if(fy>=fx-EPS&&has([a,d,c]))return true;
  }
  return false;
 };
}
function nativeDescriptor(model,field){
 if(!model.axisX?.length||!model.axisY?.length)return null;
 const xMin=Math.min(...model.axisX),xMax=Math.max(...model.axisX),yMin=Math.min(...model.axisY),yMax=Math.max(...model.axisY);
 if(!(xMax>xMin&&yMax>yMin))return null;
 // Uniform native grids retain exact source samples after axis ordering. For
 // nonuniform grids, use only fully supported numerical interpolation stencils.
 const uniform=axis=>axis.slice(2).every((v,i)=>Math.abs((v-axis[i+1])-(axis[1]-axis[0]))<1e-7);
 const regular=uniform(model.axisX)&&uniform(model.axisY),width=regular?model.nx:Math.min(201,Math.max(61,model.nx)),height=regular?model.ny:Math.min(201,Math.max(61,model.ny));
 const axisX=Array.from({length:width},(_,i)=>xMin+(xMax-xMin)*i/(width-1)),axisY=Array.from({length:height},(_,j)=>yMin+(yMax-yMin)*j/(height-1));
 const values=[],status=[],sampling=[],intervalWidths=[];
 const valueAt=index=>{const v=model.vertices[index]?.[field];return finite(v)&&(field!=='thickness'||v>0)?field==='posterior'?Math.abs(v):v:null;};
 for(let row=0;row<height;row++)for(let column=0;column<width;column++){
  const x=axisX[column],y=axisY[row],bx=bracket(model.axisX,x),by=bracket(model.axisY,y);let value=null;
  if(regular){
   const i=model.axisX[0]<model.axisX[model.nx-1]?column:model.nx-1-column,j=model.axisY[0]<model.axisY[model.ny-1]?row:model.ny-1-row;
   value=valueAt(j*model.nx+i);
  }else if(bx&&by){
   const i=bx.index,j=by.index,fx=bx.t,fy=by.t;
   const stencil=[[i,j,(1-fx)*(1-fy)],[i+1,j,fx*(1-fy)],[i,j+1,(1-fx)*fy],[i+1,j+1,fx*fy]].filter(p=>p[2]>EPS);
   if(stencil.every(([a,b])=>finite(valueAt(b*model.nx+a)))){
    const first=valueAt(stencil[0][1]*model.nx+stencil[0][0]);
    value=stencil.every(([a,b])=>valueAt(b*model.nx+a)===first)?first:stencil.reduce((sum,[a,b,w])=>sum+valueAt(b*model.nx+a)*w,0)/stencil.reduce((sum,p)=>sum+p[2],0);
   }
  }
  values.push(value);status.push(finite(value)?1:0);sampling.push(finite(value)?regular?'native':'native_resampled':null);intervalWidths.push(null);
 }
 return {schema:'nkpi-integrated-display-map-1',field,width,height,xMin,xMax,yMin,yMax,axisX,axisY,values,status,sampling,intervalWidths,
  radius_mm:model.radius,sourceKind:model.mapSource==='native'?'native':'report-image',detail:regular?'source-model-grid':'resampled-source-model-grid'};
}
function validDescriptor(d){
 if(!d||!Number.isInteger(d.width)||!Number.isInteger(d.height)||d.width<2||d.height<2||d.width>401||d.height>401)return false;
 const n=d.width*d.height;
 if(![d.xMin,d.xMax,d.yMin,d.yMax,d.radius_mm].every(finite)||d.xMin>=d.xMax||d.yMin>=d.yMax||d.radius_mm<=0)return false;
 return Array.isArray(d.values)&&Array.isArray(d.status)&&d.values.length===n&&d.status.length===n&&d.values.every(v=>v===null||finite(v))&&d.status.every(v=>[0,1,3].includes(v));
}
function countCoverage(eligible,status){
 let total=0,source=0,estimated=0,clipped=0;
 for(let k=0;k<status.length;k++)if(eligible[k]){total++;if(status[k]===1)source++;if(status[k]===2)estimated++;if(status[k]===3)clipped++;}
 const unavailable=total-source-estimated;
 // `clipped` is retained as a compatibility alias. Status 3 also includes
 // ambiguous color intervals; it is not proof of an out-of-range measurement.
 return {total,source,estimated,unavailable,uncertain:clipped,clipped,sourcePercent:total?source*100/total:0,estimatedPercent:total?estimated*100/total:0,unavailablePercent:total?unavailable*100/total:0,uncertainPercent:total?clipped*100/total:0};
}
function fitEstimate(grid,index){
 const {width,height,axisX,axisY,sourceValues,sourceStatus,sampling,intervalWidths,eligible}=grid,i=index%width,j=Math.floor(index/width),x=axisX[i],y=axisY[j];
 const sx=(grid.xMax-grid.xMin)/(width-1),sy=(grid.yMax-grid.yMin)/(height-1),rx=Math.ceil(POLICY.neighborRadiusMM/sx),ry=Math.ceil(POLICY.neighborRadiusMM/sy),points=[],quadrants=new Set();
 for(let b=Math.max(0,j-ry);b<=Math.min(height-1,j+ry);b++)for(let a=Math.max(0,i-rx);a<=Math.min(width-1,i+rx);a++){
  const k=b*width+a,dx=axisX[a]-x,dy=axisY[b]-y,d=Math.hypot(dx,dy);
  if(d>POLICY.neighborRadiusMM+EPS||!eligible[k]||sourceStatus[k]!==1||sampling[k]!=='direct')continue;
  const value=sourceValues[k],bin=intervalWidths[k];if(!finite(value)||!finite(bin)||bin<=0)continue;
  if(Math.abs(dx)>EPS&&Math.abs(dy)>EPS)quadrants.add((dx>0?1:0)+(dy>0?2:0));
  points.push({dx,dy,value,bin,w:Math.exp(-d*d/.08)});
 }
 if(points.length<POLICY.minNeighbors||quadrants.size!==4)return null;
 const matrix=Array.from({length:3},()=>[0,0,0]),rhs=[0,0,0];
 for(const p of points){const q=[1,p.dx,p.dy];for(let a=0;a<3;a++){rhs[a]+=p.w*q[a]*p.value;for(let b=0;b<3;b++)matrix[a][b]+=p.w*q[a]*q[b];}}
 const fit=solve(matrix,rhs);if(!fit)return null;
 const total=points.reduce((s,p)=>s+p.w,0),rms=Math.sqrt(points.reduce((s,p)=>s+p.w*(p.value-fit[0]-fit[1]*p.dx-fit[2]*p.dy)**2,0)/total);
 const resolution=median(points.map(p=>p.bin));if(rms>POLICY.maxResidualBinFraction*resolution+EPS)return null;
 const lo=Math.min(...points.map(p=>p.value)),hi=Math.max(...points.map(p=>p.value));
 return {value:clamp(fit[0],lo,hi),residual:rms,sourceResolution:resolution,neighbors:points.length};
}
function narrowSupport(grid,index){
 // Test the ORIGINAL local missing-color footprint, not its component's
 // distant endpoints. A long annotation can reach the rim while an interior
 // cross-section still has bounded support on both sides. The local shape
 // must be a narrow band; a broad disk/corner is not made eligible by choosing
 // a convenient diagonal through a small piece of it.
 const {width,height,axisX,axisY,sourceStatus,sampling,eligible}=grid,i=index%width,j=Math.floor(index/width),x=axisX[i],y=axisY[j];
 const sx=(grid.xMax-grid.xMin)/(width-1),sy=(grid.yMax-grid.yMin)/(height-1),rx=Math.ceil(POLICY.neighborRadiusMM/sx),ry=Math.ceil(POLICY.neighborRadiusMM/sy),missing=[],donors=[];
 for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){
  const a=i+dx,b=j+dy;if(a<0||a>=width||b<0||b>=height||!eligible[b*width+a])return null;
 }
 for(let b=Math.max(0,j-ry);b<=Math.min(height-1,j+ry);b++)for(let a=Math.max(0,i-rx);a<=Math.min(width-1,i+rx);a++){
  const k=b*width+a,dx=axisX[a]-x,dy=axisY[b]-y;
  if(Math.hypot(dx,dy)>POLICY.neighborRadiusMM+EPS||!eligible[k])continue;
  if(sourceStatus[k]===3)return null;
  if(sourceStatus[k]===0)missing.push({dx,dy});
  else if(sourceStatus[k]===1&&sampling[k]==='direct')donors.push({dx,dy});
 }
 if(missing.length<3)return null;
 const mx=missing.reduce((s,p)=>s+p.dx,0)/missing.length,my=missing.reduce((s,p)=>s+p.dy,0)/missing.length;
 let xx=0,yy=0,xy=0;for(const p of missing){xx+=(p.dx-mx)**2;yy+=(p.dy-my)**2;xy+=(p.dx-mx)*(p.dy-my);}
 const trace=xx+yy,delta=Math.hypot(xx-yy,2*xy),major=(trace+delta)/2,minor=(trace-delta)/2;
 if(major<EPS||major<POLICY.minNarrowAspect*Math.max(0,minor))return null;
 const angle=.5*Math.atan2(2*xy,xx-yy),tx=Math.cos(angle),ty=Math.sin(angle),nx=-ty,ny=tx;
 const along=missing.map(p=>p.dx*tx+p.dy*ty),across=missing.map(p=>p.dx*nx+p.dy*ny);
 const footprint=Math.abs(nx)*sx+Math.abs(ny)*sy,crossWidth=Math.max(...across)-Math.min(...across)+footprint;
 const length=Math.max(...along)-Math.min(...along)+Math.abs(tx)*sx+Math.abs(ty)*sy;
 if(crossWidth>POLICY.maxSpanMM+EPS||length<Math.max(POLICY.maxSpanMM,2*crossWidth)-EPS)return null;
 // Original direct samples must bound the gap in opposing transverse
 // directions close to this point; recovered/estimated values never qualify.
 const corridor=Math.max(sx,sy)*.8;let positive=Infinity,negative=Infinity;
 for(const p of donors){if(Math.abs(p.dx*tx+p.dy*ty)>corridor+EPS)continue;const normal=p.dx*nx+p.dy*ny;
  if(normal>EPS)positive=Math.min(positive,normal);if(normal<-EPS)negative=Math.min(negative,-normal);
 }
 const donorSpan=positive+negative-footprint;
 if(!finite(donorSpan)||donorSpan>POLICY.maxSpanMM+EPS)return null;
 return {crossWidthMM:crossWidth,donorSpanMM:Math.max(0,donorSpan)};
}
function fillSmallGaps(grid){
 const {width,height,eligible,sourceStatus,sourceValues}=grid,status=sourceStatus.slice(),values=sourceValues.slice(),seen=new Uint8Array(width*height),diagnostics=[];
 if(grid.sourceKind!=='report-image'||grid.detail==='source-model-grid'||grid.detail==='resampled-source-model-grid')return {status,values,diagnostics};
 const sx=(grid.xMax-grid.xMin)/(width-1),sy=(grid.yMax-grid.yMin)/(height-1);
 for(let start=0;start<sourceStatus.length;start++){
  if(seen[start]||!eligible[start]||sourceStatus[start]!==0)continue;
  const component=[start];seen[start]=1;let boundary=false,clipped=false,minI=width,maxI=0,minJ=height,maxJ=0;
  for(let q=0;q<component.length;q++){
   const k=component[q],i=k%width,j=Math.floor(k/width);minI=Math.min(minI,i);maxI=Math.max(maxI,i);minJ=Math.min(minJ,j);maxJ=Math.max(maxJ,j);
   for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){
    if(!dx&&!dy)continue;const a=i+dx,b=j+dy;
    if(a<0||a>=width||b<0||b>=height){boundary=true;continue;}
    const n=b*width+a;if(!eligible[n]){boundary=true;continue;}if(sourceStatus[n]===3){clipped=true;continue;}
    if(sourceStatus[n]===0&&!seen[n]){seen[n]=1;component.push(n);}
   }
  }
  const spanX=(maxI-minI+1)*sx,spanY=(maxJ-minJ+1)*sy,area=component.length*sx*sy;
  let reason=boundary?'boundary':clipped?'clipped-neighbor':Math.max(spanX,spanY)>POLICY.maxSpanMM+EPS||area>POLICY.maxAreaMM2+EPS?'size':null;
  const estimates=reason?null:component.map(index=>fitEstimate(grid,index));
  if(!reason&&estimates.some(value=>!value))reason='insufficient-local-fit';
  let filledCount=0,narrowFilled=0,maxCrossWidthMM=0;
  if(!reason){component.forEach((index,i)=>{values[index]=estimates[i].value;status[index]=2;});filledCount=component.length;}
  else for(const index of component){
   const support=narrowSupport(grid,index);if(!support)continue;
   const estimate=fitEstimate(grid,index);if(!estimate)continue;
   values[index]=estimate.value;status[index]=2;filledCount++;narrowFilled++;maxCrossWidthMM=Math.max(maxCrossWidthMM,support.crossWidthMM);
  }
  diagnostics.push({size:component.length,spanXMM:spanX,spanYMM:spanY,areaMM2:area,filled:filledCount===component.length,reason:filledCount===component.length?null:reason,
   componentRejection:reason,estimated:filledCount,remaining:component.length-filledCount,narrowFilled,maxCrossWidthMM,method:narrowFilled?'narrow-local':filledCount?'enclosed-small':null});
 }
 return {status,values,diagnostics};
}
function makeField(model,descriptor,geometry,domain='surface'){
 const d=descriptor,n=d.width*d.height,axisX=Array.from({length:d.width},(_,i)=>d.xMin+(d.xMax-d.xMin)*i/(d.width-1)),axisY=Array.from({length:d.height},(_,j)=>d.yMin+(d.yMax-d.yMin)*j/(d.height-1));
 const sourceValues=d.values.slice(),sourceStatus=d.status.slice(),sampling=Array.from({length:n},(_,k)=>d.sampling?.[k]||null),intervalWidths=Array.from({length:n},(_,k)=>d.intervalWidths?.[k]??null),eligible=new Uint8Array(n);
 const previewValues=Array.from({length:n},(_,k)=>d.status[k]===3&&finite(d.previewValues?.[k])?d.field==='posterior'?Math.abs(d.previewValues[k]):d.previewValues[k]:null);
 const uncertaintyKind=Array.from({length:n},(_,k)=>d.status[k]===3&&['endpoint','ambiguous'].includes(d.uncertaintyKind?.[k])?d.uncertaintyKind[k]:null);
 const radius=domain==='map'?d.radius_mm:Math.min(d.radius_mm,model.radius);
 let geometryUnavailable=0;
 for(let j=0;j<d.height;j++)for(let i=0;i<d.width;i++){
  const k=j*d.width+i,inside=Math.hypot(axisX[i],axisY[j])<=radius+EPS;
  eligible[k]=inside&&(domain==='map'||geometry(axisX[i],axisY[j]))?1:0;
  if(!eligible[k]){if(inside)geometryUnavailable++;sourceValues[k]=null;sourceStatus[k]=0;previewValues[k]=null;uncertaintyKind[k]=null;}
  else if(sourceStatus[k]!==1){sourceValues[k]=null;}
  else if(!finite(sourceValues[k])||(d.field==='thickness'&&sourceValues[k]<=0)){sourceValues[k]=null;sourceStatus[k]=0;}
  else if(d.field==='posterior')sourceValues[k]=Math.abs(sourceValues[k]);
 }
 const supported=sourceValues.filter((v,k)=>sourceStatus[k]===1&&finite(v));
 const base={field:d.field,width:d.width,height:d.height,xMin:d.xMin,xMax:d.xMax,yMin:d.yMin,yMax:d.yMax,axisX,axisY,sourceValues,sourceStatus,sampling,intervalWidths,previewValues,uncertaintyKind,eligible,domain,radius_mm:radius,
  sourceKind:d.sourceKind,detail:d.detail,geometryUnavailable,range:supported.length?{min:Math.min(...supported),max:Math.max(...supported),count:supported.length}:null};
 const filled=fillSmallGaps(base);
 const raw={...base,values:sourceValues.slice(),status:sourceStatus.slice(),coverage:countCoverage(eligible,sourceStatus),estimatesEnabled:false,diagnostics:filled.diagnostics};
 const estimated={...base,values:filled.values,status:filled.status,coverage:countCoverage(eligible,filled.status),estimatesEnabled:true,diagnostics:filled.diagnostics};
 return {raw,estimated};
}
function prepare(model){
 if(!model||typeof model!=='object')return {fields:{},mapFields:{},model:null,hasSurface:()=>false};
 if(cache.has(model))return cache.get(model);
 const geometry=geometryTest(model),fields={},mapFields={};
 for(const field of FIELDS){
  let descriptor=model.displayMaps?.[field];if(!validDescriptor(descriptor))descriptor=nativeDescriptor(model,field);
  if(!validDescriptor(descriptor))continue;
  const result=makeField(model,descriptor,geometry);if(result.raw.range||result.raw.coverage.uncertain)fields[field]=result;
  const mapResult=makeField(model,descriptor,geometry,'map');if(mapResult.raw.range||mapResult.raw.coverage.uncertain)mapFields[field]=mapResult;
 }
 const result={fields,mapFields,model,hasSurface:geometry};cache.set(model,result);return result;
}
function getField(prepared,field,estimates=true){return prepared?.fields?.[field]?.[estimates?'estimated':'raw']||null;}
function getMapField(prepared,field,estimates=true){return prepared?.mapFields?.[field]?.[estimates?'estimated':'raw']||null;}
function hasSurface(prepared,x,y){return finite(x)&&finite(y)&&!!prepared?.hasSurface?.(x,y);}
function sampleStatus(grid,x,y){
 if(!grid||!finite(x)||!finite(y)||x<grid.xMin-EPS||x>grid.xMax+EPS||y<grid.yMin-EPS||y>grid.yMax+EPS||finite(grid.radius_mm)&&Math.hypot(x,y)>grid.radius_mm+EPS)return null;
 const u=clamp((x-grid.xMin)/(grid.xMax-grid.xMin)*(grid.width-1),0,grid.width-1),v=clamp((y-grid.yMin)/(grid.yMax-grid.yMin)*(grid.height-1),0,grid.height-1),index=Math.round(v)*grid.width+Math.round(u),status=grid.status[index];
 return {index,status,category:status===1?'source':status===2?'estimated':status===3?'uncertain':'unavailable',eligible:!!grid.eligible[index],previewValue:status===3?grid.previewValues[index]:null,uncertaintyKind:status===3?grid.uncertaintyKind[index]:null};
}
function sample(grid,x,y){
 if(!grid||!finite(x)||!finite(y)||x<grid.xMin-EPS||x>grid.xMax+EPS||y<grid.yMin-EPS||y>grid.yMax+EPS||finite(grid.radius_mm)&&Math.hypot(x,y)>grid.radius_mm+EPS)return null;
 const u=clamp((x-grid.xMin)/(grid.xMax-grid.xMin)*(grid.width-1),0,grid.width-1),v=clamp((y-grid.yMin)/(grid.yMax-grid.yMin)*(grid.height-1),0,grid.height-1);
 const nearest=Math.round(v)*grid.width+Math.round(u),accepted=k=>(grid.status[k]===1||grid.status[k]===2)&&finite(grid.values[k]);
 // A missing sample keeps its own footprint even if neighboring values exist.
 if(!accepted(nearest))return null;
 const i=Math.min(grid.width-2,Math.floor(u)),j=Math.min(grid.height-2,Math.floor(v)),fx=u-i,fy=v-j;
 const stencil=[[j*grid.width+i,(1-fx)*(1-fy)],[j*grid.width+i+1,fx*(1-fy)],[(j+1)*grid.width+i,(1-fx)*fy],[(j+1)*grid.width+i+1,fx*fy]].filter(p=>p[1]>EPS);
 if(stencil.every(([k])=>accepted(k))){
  const estimated=stencil.some(([k])=>grid.status[k]===2),first=grid.values[stencil[0][0]],value=stencil.every(([k])=>grid.values[k]===first)?first:stencil.reduce((sum,[k,w])=>sum+grid.values[k]*w,0)/stencil.reduce((sum,p)=>sum+p[1],0);
  const contributing=stencil.map(([k])=>grid.values[k]);
  return {value,status:estimated?2:1,estimated,method:stencil.length===1?'sample':'bilinear',gradient:Math.max(...contributing)-Math.min(...contributing)>1e-10};
 }
 return {value:grid.values[nearest],status:grid.status[nearest],estimated:grid.status[nearest]===2,method:'source-footprint',gradient:false};
}
const api={FIELDS,STATUS,POLICY,prepare,getField,getMapField,hasSurface,sampleStatus,sample};
if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.NKPIIntegratedCoverage=api;
})(typeof window!=='undefined'?window:globalThis);
