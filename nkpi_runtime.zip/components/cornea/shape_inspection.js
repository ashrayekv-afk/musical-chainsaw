/* Source-only shape inspection. No fitting, extrapolation, score adjustment or
 * clinical cone definition. Returned coordinates retain the model's units/frame.
 * Display-completion meshes are intentionally not accepted as source grids.
 */
(function(root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.NKPIShapeInspection = api;
})(typeof window !== 'undefined' ? window : globalThis, function() {
  'use strict';
  const finite = Number.isFinite;
  const EPS = 1e-9;
  const vector = v => Array.isArray(v) && v.length === 3 && v.every(finite);

  function radius(model) {
    if (!model || model.kind === 'reference' || model.isAnatomy ||
        !finite(model.radius) || model.radius <= 0) return null;
    return finite(model.dataRadius) && model.dataRadius > 0
      ? Math.min(model.radius, model.dataRadius) : model.radius;
  }

  function supported(v, r) {
    return Boolean(v && vector(v.front) &&
      v.provenance !== 'filled' && v.provenance !== 'reference' &&
      v.reference !== true && v.sourceId !== -1 &&
      Math.hypot(v.front[0], v.front[1]) <= r + EPS);
  }

  function sourcePoints(model) {
    const r = radius(model);
    if (r === null || !Array.isArray(model.vertices)) return [];
    const points = [];
    model.vertices.forEach((v, index) => {
      if (supported(v, r)) points.push({v, index});
    });
    return points;
  }

  function median(values) {
    const a = values.slice().sort((x, y) => x - y), n = a.length;
    return n % 2 ? a[(n - 1) / 2] : (a[n / 2 - 1] + a[n / 2]) / 2;
  }

  // Equal values have a deterministic location: closest to the source origin,
  // then original grid order. A uniform positive offset does not invent a tip.
  function nearer(a, b) {
    const da = Math.hypot(a.v.front[0], a.v.front[1]);
    const db = Math.hypot(b.v.front[0], b.v.front[1]);
    return da < db || (da === db && a.index < b.index);
  }

  function peak(model) {
    const all = sourcePoints(model).filter(p => finite(p.v.elevation));
    const direct = all.filter(p => !p.v.interpolated);
    const directPositive = direct.filter(p => p.v.elevation > 0);
    const candidates = directPositive.length ? directPositive
      : all.filter(p => p.v.elevation > 0);
    if (!candidates.length) return null;
    const best = candidates.reduce((a, b) => b.v.elevation > a.v.elevation ||
      (b.v.elevation === a.v.elevation && nearer(b, a)) ? b : a);
    const reference = direct.length ? direct : all;
    const contrast = Math.max(0, best.v.elevation - median(reference.map(p => p.v.elevation)));
    const step = [model.legend_step, model.legend_step_um]
      .find(value => finite(value) && value > 0);
    const resolution = step === undefined ? null : step;
    return {
      index: best.index,
      x: best.v.front[0],
      y: best.v.front[1],
      elevation_um: best.v.elevation,
      contrast_um: contrast,
      resolution_um: resolution,
      // This is only comparison with a printed color step. Unknown precision
      // stays null; neither value is a clinical repeatability/progression test.
      resolved: resolution === null ? null : contrast > resolution
    };
  }

  function profileAngle(model) {
    const top = peak(model);
    if (top && Math.hypot(top.x, top.y) > EPS) return Math.atan2(top.y, top.x);
    if (top) return 0;
    const all = sourcePoints(model).filter(p => finite(p.v.thickness) && p.v.thickness > 0);
    const direct = all.filter(p => !p.v.interpolated);
    const candidates = direct.length ? direct : all;
    if (!candidates.length) return 0;
    const thin = candidates.reduce((a, b) => b.v.thickness < a.v.thickness ||
      (b.v.thickness === a.v.thickness && nearer(b, a)) ? b : a);
    return Math.hypot(thin.v.front[0], thin.v.front[1]) > EPS
      ? Math.atan2(thin.v.front[1], thin.v.front[0]) : 0;
  }

  function validAxis(axis, length) {
    if (!Array.isArray(axis) || axis.length !== length || length < 2 || !axis.every(finite)) return false;
    const direction = Math.sign(axis[1] - axis[0]);
    return direction !== 0 && axis.slice(1).every((v, i) => Math.sign(v - axis[i]) === direction);
  }

  function grid(model) {
    const r = radius(model);
    if (r === null || !Number.isInteger(model.nx) || !Number.isInteger(model.ny) ||
        !validAxis(model.axisX, model.nx) || !validAxis(model.axisY, model.ny) ||
        !Array.isArray(model.vertices) || model.vertices.length !== model.nx * model.ny) return null;
    return {model, r};
  }

  function bracket(axis, value) {
    const last = axis.length - 1, ascending = axis[last] > axis[0];
    const min = Math.min(axis[0], axis[last]), max = Math.max(axis[0], axis[last]);
    if (value < min - EPS || value > max + EPS) return null;
    value = Math.max(min, Math.min(max, value));
    let lo = 0, hi = last;
    while (hi - lo > 1) {
      const mid = (lo + hi) >> 1;
      if ((value >= axis[mid]) === ascending) lo = mid;
      else hi = mid;
    }
    return [lo, Math.max(0, Math.min(1, (value - axis[lo]) / (axis[lo + 1] - axis[lo])))];
  }

  function sampleGrid(g, x, y) {
    if (!g || !finite(x) || !finite(y) || Math.hypot(x, y) > g.r + EPS) return null;
    const {model: m} = g, bx = bracket(m.axisX, x), by = bracket(m.axisY, y);
    if (!bx || !by) return null;
    const [i, u] = bx, [j, v] = by;
    const weights = [
      [i, j, (1 - u) * (1 - v)], [i + 1, j, u * (1 - v)],
      [i, j + 1, (1 - u) * v], [i + 1, j + 1, u * v]
    ].filter(p => p[2] > 1e-12);
    const points = weights.map(([col, row, weight]) => ({
      v: m.vertices[row * m.nx + col], col, row, weight
    }));
    if (!points.length || points.some(p => !supported(p.v, g.r) ||
        Math.abs(p.v.front[0] - m.axisX[p.col]) > EPS ||
        Math.abs(p.v.front[1] - m.axisY[p.row]) > EPS)) return null;
    const total = points.reduce((sum, p) => sum + p.weight, 0);
    const weighted = get => points.reduce((sum, p) => sum + get(p.v) * p.weight, 0) / total;
    const front = [0, 1, 2].map(k => weighted(p => p.front[k]));
    const back = points.every(p => vector(p.v.back))
      ? [0, 1, 2].map(k => weighted(p => p.back[k])) : null;
    return {
      front,
      back,
      thickness: points.every(p => finite(p.v.thickness) && p.v.thickness > 0)
        ? weighted(p => p.thickness) : null,
      elevation: points.every(p => finite(p.v.elevation))
        ? weighted(p => p.elevation) : null
    };
  }

  function sample(model, x, y) {
    return sampleGrid(grid(model), x, y);
  }

  function section(model, angle, count = 121) {
    if (!Number.isInteger(count) || count < 2 || count > 2001)
      throw new RangeError('A source section requires 2–2001 sample positions.');
    const g = grid(model), a = finite(angle) ? angle : profileAngle(model);
    const top = peak(model);
    if (!g) return {angle: a, points: Array(count).fill(null), peak: top};
    const cos = Math.cos(a), sin = Math.sin(a), R = model.bfs;
    const points = Array.from({length: count}, (_, i) => {
      const distance = -g.r + 2 * g.r * i / (count - 1);
      const x = distance * cos, y = distance * sin, value = sampleGrid(g, x, y);
      if (!value) return null;
      const squared = finite(R) && R > 0 ? R * R - x * x - y * y : -1;
      return {distance, ...value,
        // Only imageModel declares this centered BFS zero. Do not infer a
        // corresponding reference height from arbitrary native z coordinates.
        reference_z: model.kind === 'estimated' && squared > 0
          ? Math.sqrt(squared) - R : null
      };
    });
    return {angle: a, points, peak: top};
  }

  return {peak, profileAngle, sample, section};
});
