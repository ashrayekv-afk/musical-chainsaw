/* Corneal pattern / follow-up, v9.1.6. Source-only descriptive mathematics.
 * No model fitting, significance threshold, inferred strength, or diagnostic output.
 * All functions are independent of the continuous 3D completion layer.
 */
(function(root){'use strict';
const node=typeof module!=='undefined'&&module.exports;
const S=node?require('./cornea/surface_schema.js'):root.CornealData;
const I=node?require('./cornea/integrated_model.js'):root.NKPIIntegratedModel;
const FIELDS=['anterior','posterior','thickness','elevation','posterior_elevation'];
const finite=v=>typeof v==='number'&&Number.isFinite(v),same=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
const fail=s=>{throw Error(s);}, copy=v=>JSON.parse(JSON.stringify(v));
const POLICY={regionRadius:1,ringInner:1.3,ringOuter:1.8,minCoverage:.8,minCells:6,landmarkRadius:3};
const META={anterior:{name:'Anterior curvature',unit:'D',digits:2},posterior:{name:'Posterior curvature |D|',unit:'D',digits:2},thickness:{name:'Thickness',unit:'µm',digits:1},elevation:{name:'Anterior elevation',unit:'µm',digits:1},posterior_elevation:{name:'Posterior elevation',unit:'µm',digits:1}};
function range(a){let lo=Infinity,hi=-Infinity;for(const x of a)if(finite(x)){lo=Math.min(lo,x);hi=Math.max(hi,x);}return lo<=hi?[lo,hi]:null;}
function mapFromNative(d,f){
 const a=f==='thickness'?d.thickness_um:f==='elevation'?d.anterior?.elevation_um:f==='posterior_elevation'?d.posterior?.elevation_um:d[f]?.curvature_D;
 if(!a)return null;
 const xSign=(d.coordinate_system.x_positive==='temporal'?1:-1)*(d.eye==='OD'?-1:1),ySign=d.coordinate_system.y_positive==='superior'?1:-1;
 const xi=d.x_mm.map((v,k)=>({v:v*xSign,k})).sort((a,b)=>a.v-b.v),yi=d.y_mm.map((v,k)=>({v:v*ySign,k})).sort((a,b)=>a.v-b.v);
 const values=yi.flatMap(y=>xi.map(x=>{const v=a[y.k][x.k];return finite(v)?f==='posterior'?Math.abs(v):v:null;}));
 if(f==='anterior'&&values.some(v=>finite(v)&&v<=0))fail('Anterior curvature must use a positive power convention.');
 let convention=null;if(f==='posterior'){const r=a.flat().filter(finite);if(!r.every(v=>v>0)&&!r.every(v=>v<0))fail('Posterior curvature needs one nonzero sign convention.');convention=r[0]<0?'negative_power':'magnitude';}
 const xs=xi.map(p=>p.v),ys=yi.map(p=>p.v),side=f==='elevation'?'anterior':f==='posterior_elevation'?'posterior':f;
 return {field:f,source:'native',x:xs,y:ys,w:xs.length,h:ys.length,values,status:values.map(v=>finite(v)?1:0),radius:null,
 definition:f==='thickness'?d.thickness_definition:f.endsWith('elevation')?copy(d[side].elevation_reference):d[f].curvature_type,
 convention,comparison:d.comparison||null,range:range(values)};
}
function reportMaps(report){
 if(report.surface){const d=S.validate(report.surface);if(d.eye!==report.eye||d.visit!==report.visit)fail('Numerical map eye/visit does not match its report.');if(d.kind!=='measured')fail('Synthetic maps cannot become patient measurements.');
  return {source:'native',maps:Object.fromEntries(FIELDS.map(f=>[f,mapFromNative(d,f)]).filter(([,m])=>m)),comparison:d.comparison||null};}
 const maps={},descriptors=I.displayMapsFor(report);
 for(const f of FIELDS){const g=descriptors[f];if(!g)continue;
  // Report values recovered from neighbouring colors, clipped bins, missing and
  // completion values are not eligible. Older undefined sampling is withheld.
  const status=g.values.map((v,k)=>g.status[k]===1&&g.sampling[k]==='direct'&&finite(v)?1:0);
  const original=report.image_maps?.find(m=>m.id===f),shape=f==='posterior_elevation'?report.shape_estimate?.posterior_elevation:report.shape_estimate;
  maps[f]={field:f,source:'report-image',x:[...g.axisX],y:[...g.axisY],w:g.width,h:g.height,values:g.values.map((v,k)=>status[k]?v:null),status,radius:g.radius_mm,
   definition:f==='thickness'?'report_pachymetry':f.endsWith('elevation')?{type:'report_relative_BFS',fit_diameter_mm:shape?.fit_diameter_mm}:original?.map_type||'unspecified',
   convention:f==='posterior'?'magnitude':null,comparison:null,range:range(g.values.filter((_,k)=>status[k]))};
 }
 return {source:'report-image',maps,comparison:null};
}
function visit(report,result){
 if(!report||!['OD','OS'].includes(report.eye)||!['first','latest'].includes(report.visit))fail('A scoped report eye and visit are required.');
 const {maps,source,comparison}=reportMaps(report),r=result?.case;
 let reported=null;if(report.thinnest_point?.verified===true&&report.thinnest_point.eye===report.eye&&report.thinnest_point.visit===report.visit&&report.thinnest_point.coordinate_system==='viewer_xy_mm'&&[report.thinnest_point.x_mm,report.thinnest_point.y_mm].every(finite))reported={x:report.thinnest_point.x_mm,y:report.thinnest_point.y_mm};
 if(!reported&&r?.eye===report.eye&&r.verified&&r.mode==='baseline'&&report.visit==='first'&&[r.landmarks?.thin_x,r.landmarks?.thin_y].every(finite))reported={x:r.landmarks.thin_x,y:r.landmarks.thin_y};
 const C=r?.verified&&r.eye===report.eye&&(report.visit==='first'||r.mode==='longitudinal')?(report.visit==='latest'?r.latest:r.first)?.C:null;
 return {eye:report.eye,slot:report.visit,source,maps,comparison,reported,verifiedC:finite(C)?C:null,quality:report.scan_quality||'unknown',sourceId:report.source_id||'',day:report.visit==='first'?0:r?.interval_days??null};
}
const cellCache=new WeakMap();
function cells(m){if(!m)return [];if(cellCache.has(m))return cellCache.get(m);const out=[];
 for(let j=0;j<m.h-1;j++)for(let i=0;i<m.w-1;i++){const x=(m.x[i]+m.x[i+1])/2,y=(m.y[j]+m.y[j+1])/2;if(m.radius&&Math.hypot(x,y)>m.radius)continue;
 const ids=[j*m.w+i,j*m.w+i+1,(j+1)*m.w+i,(j+1)*m.w+i+1],valid=ids.every(k=>m.status[k]===1&&finite(m.values[k]));
 out.push({i,j,key:j+':'+i,x,y,area:(m.x[i+1]-m.x[i])*(m.y[j+1]-m.y[j]),value:valid?ids.reduce((s,k)=>s+m.values[k],0)/4:null});}
 cellCache.set(m,out);return out;
}
function summarize(records,point,inner=0,outer=POLICY.regionRadius){
 if(!point||![point.x,point.y].every(finite))return {value:null,coverage:0,count:0,total:0,reason:'No selected region'};
 const zone=records.filter(c=>{const d=Math.hypot(c.x-point.x,c.y-point.y);return d>=inner-1e-8&&d<=outer+1e-8;}),total=zone.reduce((s,c)=>s+c.area,0),valid=zone.filter(c=>finite(c.value)),area=valid.reduce((s,c)=>s+c.area,0),coverage=total?area/total:0;
 const contained=total>=.85*Math.PI*(outer*outer-inner*inner),ready=contained&&coverage>=POLICY.minCoverage&&valid.length>=POLICY.minCells;
 return {value:ready?valid.reduce((s,c)=>s+c.value*c.area,0)/area:null,coverage,count:valid.length,total:zone.length,area_mm2:area,reason:!contained?'Region extends beyond sampled field':coverage<POLICY.minCoverage?'Insufficient source coverage':valid.length<POLICY.minCells?'Too few source cells':'',min:ready?Math.min(...valid.map(c=>c.value)):null,max:ready?Math.max(...valid.map(c=>c.value)):null};
}
function sample(m,x,y){if(!m||![x,y].every(finite))return null;let i=0,j=0;while(i<m.w-2&&m.x[i+1]<x)i++;while(j<m.h-2&&m.y[j+1]<y)j++;
 if(x<m.x[0]||x>m.x.at(-1)||y<m.y[0]||y>m.y.at(-1)||(m.radius&&Math.hypot(x,y)>m.radius))return null;
 const u=(x-m.x[i])/(m.x[i+1]-m.x[i]),v=(y-m.y[j])/(m.y[j+1]-m.y[j]),stencil=[[j*m.w+i,(1-u)*(1-v)],[j*m.w+i+1,u*(1-v)],[(j+1)*m.w+i,(1-u)*v],[(j+1)*m.w+i+1,u*v]].filter(([,w])=>w>1e-9);
 return stencil.every(([k])=>m.status[k]===1&&finite(m.values[k]))?stencil.reduce((s,[k,w])=>s+m.values[k]*w,0):null;
}
function extreme(m,mode){if(!m)return null;let best=null;for(let j=0;j<m.h;j++)for(let i=0;i<m.w;i++){const k=j*m.w+i,v=m.values[k],x=m.x[i],y=m.y[j];if(m.status[k]!==1||!finite(v)||Math.hypot(x,y)>POLICY.landmarkRadius)continue;if(!best||(mode==='min'?v<best.value:v>best.value))best={x,y,value:v};}return best;}
function landmarks(v){if(!v)return {};return {thickness:v.reported?{...v.reported,value:v.verifiedC,label:'Reported thinnest XY'}:{...extreme(v.maps.thickness,'min'),label:'Lowest supported map sample'},anterior:extreme(v.maps.anterior,'max'),posterior:extreme(v.maps.posterior,'max'),elevation:extreme(v.maps.elevation,'max'),posterior_elevation:extreme(v.maps.posterior_elevation,'max')};}
function defaultPoint(v){const p=landmarks(v).thickness;return p&&[p.x,p.y].every(finite)?{x:p.x,y:p.y,label:p.label}:{x:0,y:0,label:'Corneal vertex · minimum location unavailable'};}
function baseline(v,point){return Object.fromEntries(FIELDS.map(f=>[f,{local:summarize(cells(v?.maps[f]),point),ring:summarize(cells(v?.maps[f]),point,POLICY.ringInner,POLICY.ringOuter),point:sample(v?.maps[f],point?.x,point?.y)}]));}
function compatible(a,b,f){
 if(!a||!b||a.source!=='native'||b.source!=='native')return 'Regional change requires numerical maps; report colors are descriptive only.';
 if(a.eye!==b.eye)return 'Different eyes cannot be compared.';
 if(!a.comparison||!b.comparison||!same(a.comparison,b.comparison)||a.comparison.alignment!=='verified_common_grid')return 'A common anatomical registration must be supplied in the numerical export.';
 const ma=a.maps[f],mb=b.maps[f];if(!ma||!mb)return 'This field was not supplied for every acquisition.';
 if(!same(ma.x,mb.x)||!same(ma.y,mb.y))return 'Different spatial grids; no automatic registration or resampling is applied.';
 if(!same(ma.definition,mb.definition)||ma.convention!==mb.convention)return 'Map definitions or sign conventions differ.';
 if(f.endsWith('elevation')&&(!ma.definition?.reference_id||!mb.definition?.reference_id||ma.definition.reference_id!==mb.definition.reference_id))return 'Elevation change needs an explicitly shared reference surface.';
 if(f==='anterior'||f==='posterior'){if(!['axial','tangential','mean'].includes(ma.definition))return 'Curvature definition is unspecified.';}
 return '';
}
function regionalSeries(visits,field,point){
 const all=visits.flatMap(v=>v.scans),empty={available:false,reason:'At least two dated visits are required.',points:[],difference:null,coverage:0};
 if(visits.length<2)return empty;
 if(!visits.every(v=>Number.isInteger(v.day)&&v.day>=0)||visits.some((v,k)=>k&&v.day<=visits[k-1].day))return {...empty,reason:'Visit timing must be increasing and verified.'};
 if(visits.some(v=>v.segment!==visits[0].segment))return {...empty,reason:'Different treatment/acquisition segments. A pooled change is withheld.'};
 if(all.some(s=>s.quality==='warning'))return {...empty,reason:'A supplied acquisition has a quality warning. Review the source; it is not silently excluded.'};
 for(const s of all){const reason=compatible(all[0],s,field);if(reason)return {...empty,reason};}
 const grids=all.map(s=>cells(s.maps[field])),lookup=grids.map(cs=>new Map(cs.map(c=>[c.key,c]))),common=grids[0].map(c=>({...c,value:lookup.every(m=>finite(m.get(c.key)?.value))?c.value:null}));
 const support=summarize(common,point);if(!finite(support.value))return {...empty,reason:support.reason,coverage:support.coverage};
 const ids=new Set(common.filter(c=>finite(c.value)).map(c=>c.key));let k=0;const points=visits.map(v=>{const values=v.scans.map(()=>{const data=grids[k++].map(c=>({...c,value:ids.has(c.key)?c.value:null}));return {local:summarize(data,point),ring:summarize(data,point,POLICY.ringInner,POLICY.ringOuter)};});return {day:v.day,segment:v.segment,values:values.map(x=>x.local.value),ring:values.every(x=>finite(x.ring.value))?values.reduce((s,x)=>s+x.ring.value,0)/values.length:null,mean:values.reduce((s,x)=>s+x.local.value,0)/values.length};});
 const first=points[0],last=points.at(-1),changeCells=common.map(c=>{if(!finite(c.value))return {...c,value:null};const n0=visits[0].scans.length,n1=visits.at(-1).scans.length,va=lookup.slice(0,n0).reduce((s,m)=>s+m.get(c.key).value,0)/n0,vb=lookup.slice(-n1).reduce((s,m)=>s+m.get(c.key).value,0)/n1;return {...c,value:vb-va};});
 return {available:true,reason:'',coverage:support.coverage,points,difference:last.mean-first.mean,ringDifference:finite(first.ring)&&finite(last.ring)?last.ring-first.ring:null,changeCells,qualityUnknown:all.some(s=>s.quality!=='ok')};
}
function scalarHistory(r){
 const c=r?.case;if(!c?.verified)return [];
 const rows=[{day:0,values:c.first,quality:c.scan_quality?.first||'unknown',source:'First / only'}];
 if(c.mode==='longitudinal'&&Number.isInteger(c.interval_days)&&c.latest){rows.push({day:c.interval_days,values:c.latest,quality:c.scan_quality?.latest||'unknown',source:'Latest'});for(const h of c.history||[])if(h.eye===c.eye&&h.verified===true&&h.quality==='ok')rows.push({...h,source:'Additional verified scan'});}
 // Match the existing verified scalar-history contract: exact duplicate rows
 // have no unique acquisition ID and cannot be counted as independent repeats.
 const keys=['A','B','C','Kmax','BAD_D','ARTmax'],unique=new Map();for(const r of rows)unique.set(JSON.stringify([r.day,...keys.map(k=>r.values?.[k])]),copy(r));
 const byDay=new Map();for(const r of unique.values()){if(!byDay.has(r.day))byDay.set(r.day,[]);byDay.get(r.day).push(r);}
 return [...byDay].sort((a,b)=>a[0]-b[0]).map(([day,rows])=>({day,rows}));
}
function validateHistory(raw,binding,eye){
 const allowed=['schema','eye','case_binding_sha256','device_key','protocol_key','visits'];if(!raw||Object.keys(raw).some(k=>!allowed.includes(k))||raw.schema!=='nkpi-pattern-history-1')fail('Use the documented nkpi-pattern-history-1 JSON; identifiers are not accepted.');
 if(raw.eye!==eye||raw.case_binding_sha256!==binding||!/^[a-f0-9]{64}$/.test(binding||''))fail('History is not bound to the selected eye and current confirmed case.');
 const validKey=x=>typeof x==='string'&&/^[A-Za-z0-9_.-]{1,64}$/.test(x)&&!/^REPLACE_|^CONFIRM_/.test(x);if(!validKey(raw.device_key)||!validKey(raw.protocol_key))fail('Provide non-identifying device and protocol keys.');
 if(!Array.isArray(raw.visits)||raw.visits.length<1||raw.visits.length>12)fail('Supply 1–12 visits.');let scans=0;const ids=new Set();
 const visits=raw.visits.map((v,k)=>{
  if(!v||Object.keys(v).some(k=>!['day','segment','acquisitions'].includes(k))||!Number.isInteger(v.day)||v.day<0||v.day>36525||(!k&&v.day!==0)||(k&&v.day<=raw.visits[k-1].day))fail('Use day 0 first, then increasing whole days; no duplicate visits.');
  if(!validKey(v.segment)||!Array.isArray(v.acquisitions)||!v.acquisitions.length||v.acquisitions.length>6)fail('Each visit needs a segment key and 1–6 acquisitions.');
  return {day:v.day,segment:v.segment,scans:v.acquisitions.map(a=>{
   if(!a||Object.keys(a).some(k=>!['id','quality','maps'].includes(k))||!validKey(a.id)||ids.has(a.id)||!['ok','warning','unknown'].includes(a.quality))fail('Acquisitions need unique non-identifying IDs and explicit quality.');ids.add(a.id);if(++scans>40)fail('At most 40 acquisitions are allowed.');
   const d=S.validate(a.maps);if(d.kind!=='measured'||d.eye!==eye||d.visit!==(k?'latest':'first'))fail('The numerical map kind, eye or visit slot is inconsistent.');
   const normalized=reportMaps({eye,visit:d.visit,surface:d});return {...normalized,eye,slot:d.visit,day:v.day,sourceId:a.id,quality:a.quality,reported:null,verifiedC:null};
  })};
 });
 // A shared frame declaration is required even for field-specific checks later.
 const first=visits[0].scans[0];if(!first.comparison||visits.some(v=>v.scans.some(a=>!same(a.comparison,first.comparison))))fail('Every scan must declare the same verified common grid and map-definition keys.');
 return {schema:raw.schema,eye,binding,device:raw.device_key,protocol:raw.protocol_key,visits};
}
const api={FIELDS,META,POLICY,finite,range,mapFromNative,reportMaps,visit,cells,summarize,sample,extreme,landmarks,defaultPoint,baseline,compatible,regionalSeries,scalarHistory,validateHistory};
if(node)module.exports=api;else root.NKPIPatternMath=api;
})(typeof window!=='undefined'?window:globalThis);
