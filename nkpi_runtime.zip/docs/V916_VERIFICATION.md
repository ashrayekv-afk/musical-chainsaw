# v9.1.6 verification record

Test date: 2026-11-02. Environment: Python 3.13.5, Node 22.16.0,
headless Chromium via Playwright. Simulated engineering inputs only for the new
panel; the calculations were tested separately from rendering. Some numerical test
fixtures declare the accepted measured/device schema solely to exercise that code
path. They are explicitly synthetic, NEVER auto-loaded into the patient interface.

## Completed

1. **29 new source-only mathematics checks** in tests/test_pattern_lens.cjs.
   Native orientation/sign handling, independent scalar C, source coverage,
   common supports, repeats, multiple dates, registration/grid/reference gating,
   segment transitions, quality warnings, exclusion of recovered/clipped/unknown
   report-color samples, history hash/eye/schema validation, and no source mutation.
2. **All 23 JavaScript regression suites** (tests/test_*.cjs) pass, including the new
   suite. Original viewer/extractor/reconstruction tests retain their original scope.
3. **45 browser checks** on actual renderer and pattern scripts. Both eyes, all five
   fields, 3D cursor bridge, report-only/summary-only routes, native pairs/repeats,
   separate C/Kmax/B histories, audit download, binding rejection, source edits,
   next-patient clearing, mobile overflow and Canvas fallback. See browser_suite.json.
4. **10 full-component checks** on actual components/index.html and app.js with the
   original 3D renderer and real Python configuration/calculation responses.
   Form submits both eyes, response fingerprint verification succeeds, result cards
   drive both the original viewer and the new panel, and edits/clear invalidate
   old results. The extractor iframe was deliberately stubbed; this is not OCR or
   a live Streamlit hosting test. See full_component_checks.json.
5. **41 Python tests** pass. **24 eye calculations** (12 bilateral payloads across
   ages and both modes) exactly match v9.1.5 after ignoring only ui_version.
   PDFs generated for both eyes in baseline and longitudinal modes and have valid
   PDF headers and nonempty bytes. PDF clinical content/layout not newly evaluated.
6. Original files under components/cornea/, components/extractor/ and models/ are
   byte-identical to v9.1.5. Existing non-UI model logic is unchanged. New Python
   service change is the UI-version constant only. See parity_report.json.
7. Final ZIP contents, runtime hash, safe extraction, integrity manifest and clean
   package reuse are checked by build_release.py in the working build environment.

## Not completed / not established

- No live Streamlit server startup/deployment: Streamlit is not installed here and
  external package installation failed because network/DNS was unavailable.
- No fresh end-to-end OCR import or a new clinic-specific numerical export adapter.
- No native measurement accuracy, clinical diagnostic accuracy, prediction validity,
  confidence limits, or device repeatability established by these engineering tests.
- No claim that missing report data are measured or that completion is anatomical truth.
- Python 3.12 remains the existing deployment target; local tests used Python 3.13.5.

The browser was run from in-memory bundled local content because navigation to local
HTTP addresses was blocked by the environment. Actual application JavaScript and
CSS were used; only the source transport/Streamlit response and extractor boundary
were simulated as described above. No browser policy was overridden.

## Repeat core tests after deployment changes

From an extracted runtime directory:

```
python -m pytest -q
for f in tests/test_*.cjs; do node "$f" || exit; done
python tools/verify_package.py
```

Also open the actual deployed app, import a de-identified report, verify the expected
measurements and eye/visit, confirm the new panel and the unchanged natural-eye
viewer, test Next patient, and check runtime logs. A native-map registration key
must never be invented merely to enable a comparison.
