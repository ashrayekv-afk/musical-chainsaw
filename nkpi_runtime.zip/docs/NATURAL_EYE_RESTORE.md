# 9.1.5 — original natural-eye materials, current continuous measurements

The earlier anatomical renderer's procedural sclera/iris and clear corneal-shell
material were adapted to the continuous review viewer. This is a presentation revision,
not a reconstruction or model revision.

## Retained source of truth

`continuous_review.js`, `patient_shape.js`, `integrated_model.js`,
`integrated_measurements.js`, `integrated_coverage.js`, source-map processing and all
extractor files are unchanged from 9.1.4. No change to anterior/back coordinate
reconstruction, measured inputs, completion rules, source ranges, verified C, original
minimum, model coefficients, or risk score. See `CONTINUOUS_REVIEW.md` for C/XY matching
and missing-data semantics.

## Renderer

`natural_eye_base.js` draws the existing `NKPIContinuousReview.mesh` front and back
coordinates. It adds an illustrative 12 mm-radius sclera and procedural blue iris/pupil
behind the same limbus. These dimensions and iris appearance are reference anatomy,
not patient biometry or a simulation of patient vision. There is no refraction or
patient-specific optical ray tracing.

Natural eye uses shaded reference tissue with an angle-dependent clear corneal
reflection. Quantitative map colors use the existing display-only completed texture
and a separate opaque, unlit pass, so natural highlights cannot recolor a measurement.
The source-field boundary retains its real millimetre radius; the map is not stretched
outward across the entire limbus. The surrounding clear shell uses the same surface.
All cameras share the prior equal-axis orthographic transform; no forced cone or depth
exaggeration was added.

The new WebGL canvas is offscreen and composites into the existing canvas. Pointer
selection, linked cameras, slice profiles, and PNG export therefore share the same
coordinate transform. No new external libraries, remote textures, or network calls were
added. WebGL context loss switches to Canvas rendering; restoration rebuilds its GPU
resources. The fallback uses the same source/display mesh and smoothly interpolated
normals for transparency. Disposal deletes buffers/textures/programs and listeners.

## Continuity versus information

The surface remains visually continuous in all modes. Broad completed regions remain
illustrative, never exact numerical readings. Show data support reveals geometry support
in Natural eye and measurement support in map modes. Entirely absent maps and unlinked
visits/eyes remain unavailable. No demo-eye or synthetic-example button was added.

Whole surface defaults to Natural eye. Map review, five map types, Slice through point,
linked angle controls, reported-C audit and original-report access remain. The old
missing-tissue wedge is deliberately not restored; a slice line and profile inspect
thickness without cutting a gap in the eye.

## Technical references consulted

- MDN WebGL blendFunc: https://developer.mozilla.org/en-US/docs/Web/API/WebGLRenderingContext/blendFunc
- MDN WebGL depthMask: https://developer.mozilla.org/en-US/docs/Web/API/WebGLRenderingContext/depthMask
- Streamlit app file organization: https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/file-organization

This update restores appearance. It does not validate anatomical reconstruction against
native Pentacam surfaces or clinical outcomes.
