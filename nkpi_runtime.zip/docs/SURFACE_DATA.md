> **9.1.4 update:** This page records retained source-processing rules and historical
> tests through 9.1.3. Presentation rules describing gray holes, a wedge cutaway or the
> prior renderer are superseded by **CONTINUOUS_REVIEW.md**. Source arrays and numerical
> estimates remain separate from the continuous display envelope. For tests performed
> for the current release, use **V914_VERIFICATION.md**, not earlier pass counts.

# Integrated corneal viewer and source contract — 9.1.3

This document describes the current integrated viewer. The frozen NKPI calculator, regional comparison calculations, and cone tracking remain separate from this presentation model.

## One model with independent attributes

OD and OS share camera controls and the same physical scale. Whole surface and Section display the same retained coordinates. Point selection and map tint do not deform the cornea. Each selected original grid node can expose five independent fields: thickness, anterior curvature, posterior curvature magnitude, anterior elevation, and posterior elevation. Summary scalars such as Kmax, ARC, PRC, BAD-D, ARTmax, and NKPI do not generate extra deformations. Map view is a separate two-dimensional XY projection of the available maps; it does not assign a surface height to the displayed locations.

The natural view uses lighting and a translucent material. Measurement views use opaque, unlit colors. The 3D view colors supported surface triangles; Map view uses the map's own physical domain, including available report-map locations outside the reconstructed height surface. Gray marks unavailable colors, stripes mark additional display estimates, and crosshatching marks uncertain report-color previews. A numbered legend, units and a selected-value marker explain each scale. Optional contour bands follow accepted or estimated displayed numerical levels; uncertain previews do not generate contours. Colors encode values or an explicitly uncertain preview, not clinical categories or a validated cone boundary.

Color bounds are held across compatible eyes and visits in the imported case. Source provenance and map definitions determine compatibility; different definitions retain separately labeled scales. Signed elevation has a symmetric scale with a neutral zero. Curvature progresses from lower cool colors to higher warm colors; thickness reverses this direction so smaller values are warm. Display bounds round outward with five evenly spaced ticks. They can include retained source-point values, accepted full-map samples and uncertain report-color preview centers. Those bounds are display choices, not measured extrema, input calibration limits or clinical thresholds. Including a preview center in a scale does not accept it as a numerical measurement. Presentation interpolation does not create additional source-point readings.

The white globe, iris, pupil, and peripheral cornea are reference anatomy. Their assumed dimensions and placement are for visual context. They are not measurements of this patient's whole eye. The renderer does not simulate patient refraction, optical aberrations, glare, or visual acuity.

## Source association

Each report is bound to an eye, visit, and verified calculator input snapshot. Source edits, changed measurements, an eye being removed, and next-patient clearing invalidate that association. The viewer never substitutes the other eye or another visit. A missing selected visit remains unavailable.

Priority is given to a valid native numerical surface. Otherwise, usable report elevation and a verified reference sphere can supply approximate anterior geometry. Maps without height data keep their available point values and can be opened in Map view, while the 3D view explicitly states that patient surface geometry is unavailable. An absent report supplies no patient readings.

The runtime has no embedded example patient or demo-eye selector. Browser source images and grids are not included in the release archive or transmitted as calculator inputs.

## Native numerical coordinates

The existing `nkpi-corneal-surface-1` and `nkpi-corneal-maps-1` contracts are validated by `cornea/surface_schema.js`. They require:

- `kind: measured`, `source: device_numeric_export`, correct `eye` and `visit`.
- Increasing source `x_mm` and `y_mm` arrays with explicit units and missing values represented by `null`.
- A corneal-vertex origin and declared temporal/nasal, superior/inferior, and anterior/posterior directions.
- Corresponding anterior and optional posterior fields on the same coordinate axes.
- Curvature definitions and elevation-reference metadata for the supplied maps.
- Valid complete cells for a renderable numerical surface.

The adapter converts declared orientation to the viewer frame. Positive y is superior. Positive x is nasal in OD and temporal in OS. This orientation conversion may make viewer axes descend; dimensions remain unchanged. The circular aperture is limited by the supplied axis extents and the existing six-millimetre radius limit.

Native front and available back coordinates retain their supplied values at supported nodes. Device pachymetry is independent. The distance between paired front/back coordinates must not be relabeled as pachymetry. The native selected-point annotation uses a front marker and a device-thickness label, without implying that a line to the back surface measures that value.

A native map-only export has numerical map values but no patient height geometry. Its internal reference grid supports point indexing and the available maps can be displayed in the 2D Map view; the 3D view states that surface geometry is unavailable. It is not registered to report pixels by matching array dimensions. Native imports retain their existing coordinate, aperture and validity rules. This release does not restore native map values discarded with an unavailable native height node. Missing native height samples are not fabricated. Missing native posterior coordinates remain unavailable in this viewer.

See `NUMERICAL_IMPORT.md`, `MAP_COMPARISON.md` and `REGIONAL_CHANGE.md` for the existing `nkpi-surface-index.json` association workflow. These JSON contracts do not imply support for every proprietary device export.

## Report-image calibration

The automatic report route is limited to supported original Pentacam export layouts, including proportional scaling, with intact titles and legends. Phone photographs, cropped legends, rotated/mirrored pages, and undocumented layouts are not calibrated by guessing.

The standard anterior elevation map and its floating BFS are used. Enhanced, exclusion, and difference maps are not interchangeable. The reader checks map identity, printed BFS radius, plotting diameter, legend units, and the signed elevation scale. The plotting diameter is distinct from the BFS fitting diameter.

The reader retains the accepted legend anchors and calibrated range. These may be narrower than the full printed scale if an outer label cannot be corroborated. No unaccepted endpoint is silently added. A fresh import is required when an older report object lacks the calibration metadata needed for the integrated reconstruction.

The existing 41-by-41 grid samples the central two-thirds of the plotting radius for regional calculations. A separate 61-by-61 display field samples the actual full printed circle. A nine-millimetre plot can therefore provide a nine-millimetre viewer field while its central grid covers six millimetres. A smaller supported field is never stretched across the iris.

Fresh imports additionally retain an optional `display_detail` object with schema `nkpi-report-detail-grid-1`: a 121-by-121 field over the same full printed circle. Its samples use the same accepted palette and source-color checks, with an RGB decode cache for performance. A strict validator checks dimensions, diameter, coverage, value intervals, sampling provenance and aperture. This field is used only for quantitative map presentation. It does not replace the 41-by-41 regional grid, the 61-by-61 reconstruction grid, reconstructed coordinates, point readings or numerical minima. Older sources without the detailed field retain their accepted existing map grids.

The integrated adapter clones these fields. Color intervals touching an accepted calibration endpoint are conservatively excluded from accepted numerical reconstruction. Such an interval can arise from an endpoint color or ambiguous color matching; it does not establish that the device measurement is saturated or above/below a particular value. The optional crosshatched color preview is separate from the accepted numerical arrays. Original samples, missing masks, and regional inputs are not overwritten.

## Independent 2D maps, surface maps and display estimates

`integrated_model.js` adds independent `displayMaps` descriptors containing physical bounds, increasing X/Y axes, accepted values and validity/uncertainty status. Report row order is converted into positive-superior Y. Radius-unit curvature is converted using the existing map definition. The descriptors do not modify retained coordinates or selected-point fields. Separate `previewValues` contain decoded color centers only for uncertain samples; `uncertaintyKind` distinguishes an endpoint center from an interval whose center is elsewhere but touches a calibration limit. Neither case establishes an exact value or a one-sided numerical bound.

`integrated_coverage.js` prepares two display domains. `getField()` uses only the retained surface triangles for a 3D overlay. `getMapField()` uses the report map's own physical circle and axes independently of the height reconstruction and its radius. For example, a nine-millimetre report map can remain visible in Map view even when the accepted 3D reconstruction covers only a six-millimetre field. The outer map is neither stretched into the smaller field nor assigned a fabricated Z coordinate. Availability of a curvature or thickness map does not establish anterior height at the same XY position.

Both domains use source-sample footprints rather than making an entire geometry triangle unavailable because a single corner lacks its selected map value. Complete supported stencils allow display interpolation. Otherwise, a valid nearest sample retains its own footprint and a missing nearest sample retains its missing footprint. Source footprints are a raster display convention, not additional measured points. Native data retain the existing source-model representation and validity rules described above.

The status contract is:

| Status | Meaning | Presentation and numerical access |
| --- | --- | --- |
| 0 | Unavailable | Gray; no value assigned. |
| 1 | Accepted source support | Report-color estimate or supplied numerical value, according to source provenance. |
| 2 | Additional bounded display estimate | Stripes; explicit estimate label when inspected. |
| 3 | Uncertain report color | Crosshatched decoded-color preview when available; no accepted numerical value, contour, precise readout or inferred bound. |

The legacy `clipped` status/count name remains an API compatibility alias for status 3. It does not prove that every uncertain interval represents an out-of-range measurement.

The **Estimate narrow gaps** control is initially enabled for quantitative maps. It adds separate display values to eligible small enclosed components and locally narrow line-shaped gaps. The enclosed-component engineering policy remains:

- Maximum component span, including its sample footprint: 0.30 mm in either axis.
- Maximum component area: 0.075 mm².
- Original directly sampled donors within 0.45 mm, with at least eight donors covering all four quadrants.
- A local weighted-plane fit whose residual does not exceed 0.6 of the median supporting color-interval width.
- An estimate bounded by the minimum and maximum supporting donor values.

The enclosed route excludes components touching the eligible-domain boundary or uncertain-color neighbors. The narrow-line path evaluates each original missing sample locally, so a long narrow annotation does not fail solely because a distant part of the same component reaches the rim. It requires an elongated local missing footprint, a transverse width including sample footprint no greater than 0.30 mm, and nearby original direct samples on opposing transverse sides. The local major/minor variance ratio must be at least four, and its along-gap extent must be at least the larger of 0.30 mm and twice the transverse width. The opposing donor span, after accounting for the sample footprint, must also be no greater than 0.30 mm. The same eight-donor, four-quadrant, 0.45 mm neighborhood, bounded-plane and residual requirements apply. The immediate neighboring footprint must stay inside the eligible domain, and any uncertain color within the local neighborhood prevents this narrow-line estimate. The enclosed component's total-area limit does not apply to the length of an otherwise qualifying narrow line.

These are software acceptance rules, not clinical thresholds. Wide gaps, unsupported local fits, uncertain samples, and missing native numerical data are not filled. The 3D domain still cannot estimate through absent source geometry; the 2D domain can inspect independently supported report colors without claiming height. Existing locally recovered report colors and earlier additional estimates never become donors. No recursive filling is used. An unseen extremum cannot be recovered merely by fitting a smooth neighborhood.

Disabling the control removes the additional display estimates. Uncertain previews remain crosshatched, because their status is independent of the estimate toggle. Original source arrays, reconstructed point readings, the retained minimum, display scale bounds and NKPI inputs do not change with this control. The selected 2D map inspector updates when an explicitly selected location has a qualifying estimate, and marks that readout with `(est.)`.

Coverage uses the full physical map circle in Map view and map sample locations on retained supported triangles in 3D. The UI separately reports accepted source/report support, estimates, uncertain colors and unavailable samples; these four categories sum to the domain total before display rounding. Internally, the compatibility `unavailable` count includes status 3, and the separate `uncertain` count is subtracted for the UI's ordinary unavailable category. Absent surface geometry is excluded from the 3D denominator and stays open. It is included as a map location in the 2D denominator without implying a height measurement. Percentages from the two domains do not have the same denominator. Coverage is not accuracy, whole-eye coverage or a guarantee of a complete cornea.

Color scales include retained source-point ranges, full-map accepted sample ranges and available uncertain preview centers, with compatible sources held across eyes and visits. Preview centers influence only presentation bounds and the visibly uncertain color. Added estimates never expand the scales. Exact constant native fields are copied without resampling roundoff; negligible machine-precision range differences do not become exaggerated display contrast. Original numerical native coordinates and readings remain exact. A nonuniform native grid can be resampled for presentation only through complete supported stencils; missing native values are not gap-filled.

Detailed report colors and locally fitted reconstructed point readings can differ. Entering Map view without a saved manual map selection retains the source-point selection and readings. Clicking a map or adjusting its XY controls explicitly selects a map location; the five-field table then inspects the independent maps at that XY coordinate. Estimated values carry `(est.)`, uncertain colors report `Uncertain`, and missing fields report `Unavailable`. Returning to a 3D view restores the retained source-point reading and selection; the independent map selection can be restored on returning to Map view. Thinnest point clears a manual map selection and returns to the existing source-derived minimum; it does not search added estimates or preview colors for a new minimum.

For a retained source point, a distinct report-color sample is identified separately when it differs beyond displayed precision or when the original field is unavailable. Neither the detailed sample, an additional estimate, nor an uncertain preview overwrites that source point. The report-image minimum is labeled **Lowest reconstructed pachymetry**. Native numerical sources retain **Lowest mapped pachymetry**, meaning the smallest usable supplied source-grid value.

## Approximate front and inner geometry

The front is a centered, untilted reference sphere plus the signed anterior elevation. Millimetres and micrometres are converted explicitly. The report does not supply the floating sphere's complete translation and tilt, so this is an approximation.

A weighted local plane smooths readable elevation and pachymetry within a 0.6 mm neighborhood. It retains the existing requirements: at least six samples, at least 50% local support, and a nearby source sample within the existing grid-dependent distance bound. This can recover small printed-label obstructions; it cannot accept a sample excluded for calibration uncertainty.

A complete model requires at least 50% usable support within its chosen aperture. The full display field is attempted first, with a central-field fallback when appropriate. If conservative censoring causes the complete-model gate to fail, the viewer may show only locally supported patches in the previously accepted aperture. It records the original rejection and labels the result **Partial report-image reconstruction**. These are software processing rules, not clinical accuracy thresholds.

Front cells whose intervals touch the accepted calibration limits are removed after fitting so neighboring samples cannot fill them back. Triangles require supported vertices; unsupported regions remain open. Version 9.1.3 additionally retains the triangle formed by three available original corners of a grid cell when the fixed diagonal would omit it. It does not add a vertex, span more than one original cell, move a coordinate, or bridge the missing fourth corner. Cells with fewer than three supported corners remain empty, and fully supported cells retain their existing triangles. Native topology is unchanged. Display normals can update near added triangles; quantitative fields, source vertex coverage and minima remain unchanged. No harmonic surface completion is used within the patient source field by this integrated viewer.

When matching pachymetry exists, the front is offset inward along its reconstructed local normal by the retained thickness. The full three-dimensional distance equals that thickness; the method does not use a vertical z-only gap. This is a thickness-derived inner boundary, not an independently measured posterior surface. Missing or censored pachymetry leaves the corresponding inner point unavailable. Mismatched plot diameters and ambiguous duplicate thickness maps are not combined.

## Independent posterior elevation

A standard posterior elevation map has its own floating BFS. Its radius, map identity, plotting diameter, and signed legend are checked separately. Generic OCR crops and repeated source reads are used; no patient-specific header values or manual transcriptions are embedded in production code.

Posterior elevation is an x/y point attribute. It never replaces absolute posterior z coordinates or generates front/back separation. The fitting diameter remains separate from the plotting diameter and may be unavailable if unreadable.

After conservative calibration-interval exclusion, a sparse posterior field may still provide a point value where the entire interpolation stencil is accepted and supported. Its sparse status is retained. A crosshatched posterior color preview is not an accepted posterior-elevation value or a posterior surface height. This local attribute does not turn an incomplete posterior map into an accepted complete surface.

Anterior report radii are converted to dioptres using 337.5/r. Posterior radius values use 40/r and are labeled as magnitude, |D|. Native posterior dioptres retain their supplied field but are displayed consistently as magnitude in that mode. Elevation retains its sign. Report-derived readouts carry the approximate marker.

## Reference anatomy and viewing

Reference peripheral tissue is outside the sampled aperture. A transition supplies visual context toward a reference limbus and globe without moving retained patient vertices. No point measurements are assigned to that reference tissue. Unavailable regions within the source field remain open rather than being labeled as measured tissue.

The Section setting removes part of the displayed shell to expose the available interior. It is a viewing cut, not pathology. Its radial edge is aligned with that eye/visit's lowest supported mapped pachymetry. Cut walls follow retained mesh adjacency and supported front/back points. Point X/Y controls select existing grid indices and do not deform the surface. A manually chosen point within the viewing cut retains its numerical readings; the viewer directs the user to Whole surface instead of placing a floating caliper in the opening.

The initial selection minimizes finite positive mapped thickness among supported vertices with valid front coordinates. It does not favor points with more available measurements. Equal minima use a deterministic central-distance/index tie break. Each eye and visit has an independent selection; changing the displayed field preserves it, and Thinnest point resets it. If thickness is unavailable, the viewer keeps an explicit unavailable state and does not infer a minimum from another field.

For report images, this is **Lowest reconstructed pachymetry**, the minimum of the supported reconstructed samples. Color quantization, local fitting and incomplete support can make it differ from the source report's scalar C or the finer color-display field. A scalar minimum without its validated spatial location cannot establish a 3D position, so it is never substituted at a different node. The selected minimum is not assumed to coincide with maximum curvature, maximum elevation or a validated cone apex.

A locally supported sample can be isolated from the retained triangle mesh when neighboring source cells are unavailable. Its lower thickness remains the selected minimum; it is not replaced by a thicker connected node. The viewer labels the surrounding surface as unavailable and uses a point-only annotation instead of inventing triangles or a tissue caliper. This is distinct from a valid surface point temporarily hidden by the Section viewing cut.

The renderer uses local WebGL without external textures. A Canvas fallback displays the supported source mesh with simpler material effects when WebGL cannot initialize. Source measurements remain available if the graphics context is interrupted. Disposal releases listeners, observers, and graphics resources when the source or visit changes.

Native and report geometry use the same units on all axes. Both eye panels use the same pixels per millimetre, including when their CSS dimensions differ slightly. There is no artificial elevation amplification in this integrated view. Earlier and latest reconstructions are independent, not registered tissue motion.

The PNG export includes both views, selected point or map-location values and selection status, visit, source status, limitations, color legends, map coverage and display-estimate state. A Map view export identifies the two-dimensional XY projection and whether surface height is independently available at the selected location. Estimated and uncertain provenance remains visible. The export does not include source report images or patient identifiers.

## Accuracy boundary

A convincing appearance does not establish patient accuracy. Printed color quantization, ambiguous color matching, unreadable areas, clipped scales, unknown reference pose, and scan repeatability limit report reconstruction. A more complete 2D map shows information that was previously hidden by missing height geometry; it does not establish those missing heights. Native coordinates support closer corneal geometry but do not measure the iris or entire globe. No display mode guarantees a complete measured cornea or a 1:1 whole-eye replica. The viewer is not a clinically validated surgical-planning surface or optical model.

Background on elevation references and curvature:

Belin and Khachikian, 2008, *An introduction to understanding elevation-based topography: how elevation data are displayed*.
https://www.pentacam.com/fileadmin/user_upload/pentacam.de/downloads/publikationen/artikel/2008-Article__Pentacam_An_introduction_understand_elevation_based_topography.pdf

Color-scale background: Matplotlib, *Choosing Colormaps*, describes sequential scales for ordered values and diverging scales around a meaningful midpoint.
https://matplotlib.org/stable/users/explain/colors/colormaps.html

The software behavior is defined by `integrated_model.js`, `image_regions.js`, `patient_shape.js`, `integrated_measurements.js`, `integrated_coverage.js`, and `integrated_eye.js`. See `TEST_REPORT.md` for verification scope and limits.
