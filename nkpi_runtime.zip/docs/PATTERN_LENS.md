# Corneal pattern & follow-up — implementation and data contract

## Purpose

A descriptive addition below the original 3D viewer. Single-visit observations are
not forecasts. Two visits provide a difference; additional visits and repeats reveal
observations, not a validated disease classifier. No probability, significance test,
interday precision limit, clinical cutoff, treatment advice, or tissue strength is
inferred. References inform design; they do not validate this implementation.

## Data flow and identity

`app.js` still verifies each Python result against its immutable case snapshot.
`regional_change.js` exposes only report sets already bound to that same input.
`pattern_lens.js` consumes these sets plus confirmed results. It never writes to
case values, the models, extractor, or 3D vertices. A callback offers getPoint /
focusPoint to the original renderer; this moves the cursor only.

The new section clears attached history on source/input snapshot changes or clear.
The history's case_binding_sha256 is the existing input_sha256. This ties it to a
confirmed input snapshot, NOT a unique patient identity; identical inputs can share
that hash. The user must separately verify same-patient, same-eye association. Do not
use patient identifiers as keys. Unknown top-level fields are rejected.

## Ordinary single / two-visit reports

Native grids use `nkpi-corneal-surface-1` or `nkpi-corneal-maps-1` and the existing
surface validator. Axis declarations are converted once to the existing viewer XY
frame (x to the viewer's right, y superior). OD and OS remain independent. Posterior
power is explicitly displayed as magnitude |D| and a mixed/zero sign convention is
rejected. Coordinate/reference correctness remains the converter's responsibility.

Image maps use the independent detailed color grid, not reconstructed mesh heights.
Accepted status=1 samples additionally require sampling='direct'. Endpoint-clipped,
ambiguous, unknown sampling, local-color recovery, all display completion, and all
3D smoothing are excluded. Color-based readings are approximate and descriptive.
They may be fewer than the pixels visible in the visually completed 3D model.

A complete four-source-corner cell contributes its mean corner value at its center,
weighted by its planar XY area. A 2 mm-diameter disk requires at least 80% accepted
cell area, 6 complete cells, and sampled area >=85% of the ideal disk to limit edge
truncation. These are engineering visibility rules, not clinical criteria. Counts
are spatial samples, NOT independent patients or replicates. A selected-point read
uses the supported bilinear stencil only. The 1.3–1.8 mm annulus is spatial context,
not a healthy or stable reference.

Landmarks are source-node extrema within the central 6 mm, except explicit valid
reported thinnest XY, which is used when supplied. Otherwise the initial marker is
the lowest supported map sample, not an invented location for scalar C. A confirmed
single-visit thin_x / thin_y is accepted; unscoped longitudinal landmarks are not
reused across visits. Kmax, C and B from the main calculator remain separate from
these spatial means and extrema. Missing support can bias the apparent location.

## Regional differences

Automatic first/latest quantitative review requires native numerical maps, the same
eye, strictly increasing known day offsets, matching map definitions and axes, and
identical explicit comparison metadata with alignment='verified_common_grid'. No
registration, resampling, smoothing or estimated gap values are introduced here.
Curvature types must be axial, tangential or mean and must match. Signed posterior
power convention must also match. Elevation requires equal reference descriptors and
an explicit shared reference_id. Thickness definition must be device_pachymetry.

For all included visits and repeat acquisitions, intersect the complete source-cell
masks once. Use those identical cells at every acquisition. Compute area-weighted
regional means per scan, then unweighted arithmetic means across scans per visit.
Difference = selected visit mean minus baseline visit mean. Negative thickness
means thinning; positive curvature magnitude means steepening. The ring is analyzed
separately on the same support intersection.

Quality-warning scans withhold regional change rather than being silently dropped.
Unknown quality is cautioned. A pooled regional change across different supplied
segments is withheld. In the ordinary first/latest workflow, treatment must be
confirmed 'untreated'; otherwise attach documented segmented numerical history.
The app does not infer treatment dates or establish interday repeatability.

Native charts preserve every acquisition with its visit mean and min–max range.
There is no confidence band, fitted forecast or diagnostic direction count. Identical
coordinates and keys are a supplied declaration of registration, not proof of it.

## Confirmed scalar histories

C, Kmax and B use result.case.first/latest and the existing verified scalar history
contract. They are not extracted from the new maps. Exact duplicate scalar vectors
at the same day are deduplicated because those rows have no acquisition ID. Explicit
additional scalar-history rows require existing verified/quality-ok association.
First/latest warning readings remain visible with a caution. Curves connect only
quality-ok untreated observations; unresolved context observations stay unconnected.
This plot does not change the underlying calculation or claim a natural-history fit.

## Additional numerical history JSON

The advanced attachment is a separate, read-only path for extra visits and repeated
native maps. Ordinary ZIP import is still first/latest, not an arbitrary scan archive.
The template downloads the CURRENT eye's input hash; replace placeholders only with
verified data. The package does not ship a real numerical vendor adapter.

Top-level example structure (maps omitted for brevity; not an importable example):

```json
{
  "schema": "nkpi-pattern-history-1",
  "eye": "OD",
  "case_binding_sha256": "the_current_result_input_sha256",
  "device_key": "device_1",
  "protocol_key": "scan_protocol_1",
  "visits": [
    {"day": 0, "segment": "untreated_segment_1", "acquisitions": [
      {"id": "acq_001", "quality": "ok", "maps": "FULL_NUMERICAL_MAP_OBJECT"}
    ]},
    {"day": 180, "segment": "untreated_segment_1", "acquisitions": [
      {"id": "acq_002", "quality": "ok", "maps": "FULL_NUMERICAL_MAP_OBJECT"},
      {"id": "acq_003", "quality": "ok", "maps": "FULL_NUMERICAL_MAP_OBJECT"}
    ]}
  ]
}
```

Limits: <=24 MB JSON; 1–12 visits; first day=0 then strictly increasing integer days;
1–6 acquisitions per visit and <=40 total. IDs and device/protocol/segment keys must
be non-identifying [A-Za-z0-9_.-], 1–64 characters. Duplicate IDs, unknown schema
fields and REPLACE_/CONFIRM_ placeholders are rejected. Acquisition quality must be
ok/warning/unknown. Maps follow the existing numerical schemas. Each acquisition
must be measured/device_numeric_export and correct eye. Map visit slot is first
for day0 and latest for ALL later visits. The separate day offsets retain chronology.
Every map requires the same declared comparison registration/definition keys.

Relative days, not filenames, define spacing. Separate treatment/acquisition regimes
use different segment keys. The current UI withholds a combined regional delta when
its included history spans segments; it does not fit separate treatment models.
3D cursor bridges are disabled for attached history because these are separate scans
not automatically substituted into the first/latest 3D viewer. Removing the history
restores the source-bound main-case bridge. Nothing is sent to the Python scoring
endpoint; no localStorage persistence or additional external request is used.

## Audit and source limits

Local JSON audit includes source, input hash, eye, selected coordinates, review
settings, every native acquisition mean or image-description mean, coverage, scalar
history and field-specific gating reasons. It is a research processing record, not
a clinical report certification. Review scan quality, lens wear and interventions.
Use de-identified data on unapproved deployments.

## Research informing this design

- https://www.nature.com/articles/s41598-021-95503-8 — interday measurement variability.
- https://pubmed.ncbi.nlm.nih.gov/34050086/ — research on zonal parameters.

Neither paper evaluates or validates this source code, region dimensions, source
thresholds, visual completion, or input adapter. A separate patient-level and
external evaluation is needed before clinical claims.
