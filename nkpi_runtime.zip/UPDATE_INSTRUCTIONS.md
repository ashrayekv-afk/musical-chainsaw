# Update to 9.1.5-original-natural-eye

Extract the outer download once. Upload the four root files plus
`.streamlit/config.toml`. Keep `nkpi_runtime.zip` zipped and upload it with its matching
`kcn_dual_calculator_app.py`. Main file remains `kcn_dual_calculator_app.py`, target Python
3.12. Reboot, refresh and confirm the footer version. Restore the original reports to
this browser session, verify measurements and calculate. Natural eye is the default;
choose a quantitative map without changing the underlying geometry. See README.md.
